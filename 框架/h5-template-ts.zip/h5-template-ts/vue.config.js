/* eslint-disable @typescript-eslint/no-var-requires,@typescript-eslint/explicit-function-return-type */
// const CompressionPlugin = require("compression-webpack-plugin");
const TencentcloudPlugin = require("webpack-tencentcloud-plugin").default;
const { uploadOption, uploadPath, upload } = require("./src/config/oss");
const path = require("path");
function resolve(dir) {
    return path.resolve(__dirname, dir);
}
module.exports = {
    outputDir: process.env.outputDir,
    // 静态资源路径
    assetsDir: "assets",
    publicPath: process.env.VUE_APP_MODE === "development" ? "/" : upload ? uploadPath : "",
    lintOnSave: true,
    // 包含运行时编译器的 Vue 构建版本
    runtimeCompiler: true,
    // 配置生产环境SourceMap
    productionSourceMap: false,
    // 调整内部的 webpack 配置。
    // 查阅 https://github.com/vuejs/vue-doc-zh-cn/vue-cli/webpack.md
    chainWebpack: (config) => {
        // 配置标题
        config.plugin("html").tap((args) => {
            args[0].title = "加载中...";
            return args;
        });
        // 添加别名
        config.resolve.alias.set("@", resolve("src"));
        // 移除全局preload 插件
        config.plugins.delete("preload");
        // 移除全局prefetch 插件
        config.plugins.delete("prefetch");
        // 打包分析
        if (process.env.npm_config_report) {
            config.plugin("webpack-bundle-analyzer").use(require("webpack-bundle-analyzer").BundleAnalyzerPlugin).end();
        }
        // 生产环境踢除vconsole
        if (process.env.VUE_APP_MODE === "production") {
            config.set("externals", [
                // {
                //     vconsole: "vconsole"
                // }
            ]);
        }
        // 非开发环境oss上传
        if (process.env.VUE_APP_MODE !== "development" && upload) {
            config.plugin("webpack-tencentcloud-plugin").use(new TencentcloudPlugin(uploadOption)).end();
        }
        // 更改图片资源地址到cdn
        config.module
            .rule("images")
            .test(/\.(jpe?g|png|gif|svg)$/)
            .exclude.add(resolve("src/assets/svg"))
            .end()
            .use("url-loader")
            .loader("url-loader")
            .options({
                limit: 1024, // 单位byte，小于1kb的将转换成base64
                // 以下配置项用于配置file-loader
                // 根据环境使用cdn或相对路径
                // eslint-disable-next-line prettier/prettier
                publicPath: process.env.VUE_APP_MODE === "development" ? "/assets/img" : upload ? `${uploadPath}/assets/img` : "/assets/img",
                // 将图片打包到dist/img文件夹下, 不配置则打包到dist文件夹下
                outputPath: "assets/img",
                // 配置打包后图片文件名
                name: "[name].[contenthash].[ext]"
            })
            .end();
        // 删除默认配置中的svg处理
        config.module.rules.delete("svg").end();
        config.module
            .rule("svg")
            .test(/\.svg$/)
            .include.add(resolve("src/assets/svg"))
            .end()
            .use("svg-sprite-loader")
            .loader("svg-sprite-loader")
            .options({
                symbolId: "svg-[name]"
            })
            .end();
    },
    pluginOptions: {
        "style-resources-loader": {
            preProcessor: "scss",
            patterns: [resolve("./src/styles/utils/*.scss")]
        }
    },
    configureWebpack: () => {
        return {
            plugins: [
                // new CompressionPlugin({
                //     /** gzip压缩**/
                //     filename: "[path].gz[query]",
                //     algorithm: "gzip",
                //     test: /\.js$|\.css$|\.html$|\.eot?.+$|\.ttf?.+$|\.woff?.+$|\.svg?.+$/,
                //     threshold: 10240,
                //     deleteOriginalAssets: false,
                //     minRatio: 0.8
                //     /** Brotli压缩**/
                //     // filename: '[path].br[query]',
                //     // algorithm: 'brotliCompress',
                //     // test: /\.(js|css|html|svg)$/,
                //     // compressionOptions: { level: 11 },
                //     // threshold: 10240,
                //     // minRatio: 0.8,
                //     // deleteOriginalAssets: false
                // })
            ],
            optimization: {
                splitChunks: {
                    chunks: "all",
                    maxInitialRequests: 30,
                    maxAsyncRequests: 30,
                    minSize: 2048,
                    cacheGroups: {
                        "frame-view": {
                            name: "frame-view",
                            test: /[\\/]src[\\/](layout)[\\/]/,
                            priority: 11
                        },
                        "vendors/vue-bucket": {
                            name: "vendors/vue-bucket",
                            test: /[\\/]node_modules[\\/](vue|vue-router|vuex|vue-class-component)[\\/]/,
                            priority: 10
                        },
                        "vendors/ui": {
                            name: "vendors/ui",
                            test: /[\\/]node_modules[\\/](vant|element-ui)[\\/]/,
                            priority: 9
                        },
                        "vendors/library": {
                            name: "vendors/library",
                            test: /[\\/]node_modules[\\/]/,
                            priority: 8
                        },
                        "vendors/sentry": {
                            name: "vendors/sentry",
                            test: /[\\/]node_modules[\\/](@sentry)[\\/]/,
                            priority: 7
                        },
                        "vendors/vconsole": {
                            name: "vendors/vconsole",
                            test: /[\\/]node_modules[\\/](vconsole)[\\/]/,
                            priority: 7
                        },
                        "vendors/hammerjs": {
                            name: "vendors/hammerjs",
                            test: /[\\/]node_modules[\\/](hammerjs)[\\/]/,
                            priority: 6
                        },
                        "vendors/core-js": {
                            name: "vendors/core-js",
                            test: /[\\/]node_modules[\\/](core-js)[\\/]/,
                            priority: 5
                        },
                        default: {
                            name: "common",
                            chunks: "initial",
                            minChunks: 4,
                            reuseExistingChunk: true
                        }
                    }
                }
            }
        };
    },
    // 配置开发选项
    devServer: {
        hot: true,
        disableHostCheck: true,
        open: false,
        host: "0.0.0.0",
        port: 16000,
        https: false,
        hotOnly: false,
        // 查阅 https://github.com/vuejs/vue-doc-zh-cn/vue-cli/cli-service.md#配置代理
        proxy: {
            "/proxy_url": {
                target: process.env.VUE_APP_PROXY_URL,
                changeOrigin: true,
                secure: false,
                ws: true,
                pathRewrite: {
                    "^/proxy_url": ""
                }
            }
        }
    }
};
