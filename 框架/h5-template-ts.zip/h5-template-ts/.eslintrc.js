module.exports = {
    extends: ["@syyfe/eslint-config-vue2ts"],
    rules: {
        //是否禁止console.log
        "no-console": process.env.NODE_ENV === "production" ? "warn" : "off",
        //是否禁止debugger
        "no-debugger": process.env.NODE_ENV === "production" ? "warn" : "off"
    }
};
