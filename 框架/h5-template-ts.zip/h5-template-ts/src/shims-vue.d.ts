declare module "*.vue" {
    import Vue from "vue";
    export default Vue;
}

declare module "weixin-js-sdk";
declare module "webpack-tencentcloud-plugin";

declare module "vue-awesome-swiper";
