<template>
    <div class="root top-safe-area bottom-safe-area" @touchmove="handleTouch">
        <keep-alive>
            <!-- 缓存的视图 -->
            <router-view v-if="$route.meta.keepAlive"></router-view>
        </keep-alive>
        <transition :name="transitionName">
            <!-- 不缓存的视图 -->
            <router-view v-if="!$route.meta.keepAlive"></router-view>
        </transition>
    </div>
</template>
<script lang="ts">
import { Vue, Component, Watch } from "vue-property-decorator";
import BaseTabbar from "@/resources/components/base-tabbar/index.vue";
import { clearRequest } from "@/packages/request/index";
import { Route } from "vue-router";

type _TouchEvent = TouchEvent & {
    _isScroller?: boolean;
};

@Component({
    components: {
        BaseTabbar
    }
})
export default class App extends Vue {
    /**路由切换class*/
    transitionName = "";

    /**监听路由*/
    @Watch("$route")
    onRouteChange(to: Route, from: Route): void {
        /**路由切换时，删除请求队列*/
        clearRequest();

        /**路由切换动画*/
        const is_back = this.$store.state.isBack;
        if (is_back === null || (to.meta?.isTabbar && from.meta?.isTabbar)) {
            /** 页面初始化，tab切换的时候，不显示动画 */
            this.transitionName = "";
            this.$store.commit("SET_ISBACK", false);
        } else if (is_back === true) {
            this.transitionName = "slide-left";
            this.$store.commit("SET_ISBACK", false);
        } else {
            this.transitionName = "slide-right";
        }

        /** 路由切换的时候清除相关提示 */
        this.$notify.clear();
        this.$toast.clear();
    }

    /** 监听浏览器后退事件 */
    handleListenBack(): void {
        window.addEventListener(
            "popstate",
            () => {
                this.$store.commit("SET_ISBACK", true);
            },
            false
        );
    }
    /** 禁止页面级的touchmove事件 */
    disableTouchMove(): void {
        document.body.addEventListener(
            "touchmove",
            function (e: _TouchEvent) {
                if (e._isScroller) return;
                // 阻止默认事件
                e.preventDefault();
            },
            {
                passive: false
            }
        );
    }
    /** 允许页面内部body的touchmove事件 */
    handleTouch(e: _TouchEvent): void {
        e._isScroller = true;
    }

    created(): void {
        this.disableTouchMove();
        this.handleListenBack();
    }
}
</script>
<style lang="scss" scoped>
.root {
    background-color: #f4f5f6;
    height: 100%;
    overflow-y: auto;
}
.top-safe-area {
    padding-top: constant(safe-area-inset-top);
    padding-top: env(safe-area-inset-top);
}
.bottom-safe-area {
    padding-bottom: constant(safe-area-inset-bottom);
    padding-bottom: env(safe-area-inset-bottom);
}
</style>
