<template>
    <frame-view :tabbar="true">
        <router-link to="dev">进入开发者中心</router-link>
    </frame-view>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
@Component({
    name: "Index",
    components: {}
})
export default class Index extends Vue {}
</script>

<style lang="scss" scoped></style>
