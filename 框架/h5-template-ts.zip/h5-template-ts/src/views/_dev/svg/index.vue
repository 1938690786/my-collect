<template>
    <base-svg name="user" color="#000" :width="40" :height="40"></base-svg>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
import BaseSvg from "@/resources/components/base-svg/index.vue";
@Component({
    name: "Index",
    components: {
        BaseSvg
    }
})
export default class Index extends Vue {}
</script>

<style lang="scss" scoped></style>
