<template>
    <base-list :custom-style="listWrapperStyle" :req="getList" row-key="product" :list.sync="list">
        <template #item="scope">
            <div class="title" @click="handleChangeItem(scope.index, scope.row)">
                <p>title(点击可以修改):{{ scope.row.name }}</p>
                <p>index:{{ scope.index }}</p>
            </div>
        </template>
        <template #default>
            <span>slot插槽</span>
        </template>
    </base-list>
</template>

<script lang="ts">
import { Vue, Component, Watch } from "vue-property-decorator";
import BaseList from "@/resources/components/base-list/index.vue";
import getRealPx from "@/utils/tools/get-realpx/index";
import { listlevel } from "@/config/apis/dev";
import { BaseListReq } from "/#/base";
@Component({
    name: "List",
    components: {
        BaseList
    }
})
export default class List extends Vue {
    get listWrapperStyle(): any {
        return {
            padding: `${getRealPx(20)}px`
        };
    }
    getList: BaseListReq = {
        fn: listlevel,
        params: {
            tt: 1,
            size: 10
        }
    };
    list = [];
    @Watch("list")
    changeList(): void {
        console.log("外部list：", this.list);
    }
    handleChangeItem(index: number, item: any): void {
        item.name = new Date().getTime();
    }
}
</script>

<style lang="scss" scoped>
.wrapper {
    padding: 20px;
}
.title {
    width: 500px;
    height: 200px;
    background: "#1e1e1e";
    font-size: 24px;
}
</style>
