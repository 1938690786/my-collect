<template>
    <div class="progress">
        <base-progress
            ref="progress"
            class="progress-bar"
            :stroke-width="670"
            :stroke-hidth="26"
            text-position="left"
            track-color="#ffffff"
            text-color="#000000"
            track-border-color="#ED0017"
            color="linear-gradient(to right, #FF8542, #FF7123,#ED0017)"
        >
            <template #other>
                <div
                    class="other-content"
                    :style="{
                        width: getRealPx(670)
                    }"
                >
                    进度文案居左
                </div>
            </template>
        </base-progress>

        <base-progress
            ref="progress"
            class="progress-bar"
            :stroke-width="670"
            :stroke-hidth="26"
            text-position="center"
            track-color="#ffffff"
            text-color="#000000"
            track-border-color="#ED0017"
            color="linear-gradient(to right, #FF8542, #FF7123,#ED0017)"
        >
            <template #other>
                <div
                    class="other-content"
                    :style="{
                        width: getRealPx(670)
                    }"
                >
                    进度文案居中
                </div>
            </template>
        </base-progress>

        <base-progress
            ref="progress"
            class="progress-bar"
            :stroke-width="670"
            :stroke-hidth="26"
            text-position="right"
            track-color="#ffffff"
            text-color="#000000"
            track-border-color="#ED0017"
            color="linear-gradient(to right, #FF8542, #FF7123,#ED0017)"
        >
            <template #other>
                <div
                    class="other-content"
                    :style="{
                        width: getRealPx(670)
                    }"
                >
                    进度文案居右
                </div>
            </template>
        </base-progress>
    </div>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
import BaseProgress from "@/resources/components/base-progress/index.vue";
import getRealPx from "@/utils/tools/get-realpx/index";
@Component({
    name: "Progress",
    components: {
        BaseProgress
    }
})
export default class Progress extends Vue {
    // w = 670;
    // mounted(): void {
    //     setTimeout(() => {
    //         this.w = 500;
    //         console.log(333);
    //         (this.$refs["progress"] as any).resize();
    //     }, 5000);
    // }
    getRealPx(px: number): string {
        return getRealPx(px) + "px";
    }
}
</script>

<style lang="scss" scoped>
.progress {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #ffffff;
    padding: 50px 0px;
    h1 {
        font-size: 36px;
        padding: 0 20px;
    }
    &-bar {
        font-size: 24px;
        .other-content {
            margin: 0 auto;
            padding: 20px 0;
        }
    }
}
</style>
