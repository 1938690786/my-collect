<template>
    <base-loading :loading="loading" :error="error" message="测试" @retry="handleRetry">
        <p>加载完成</p>
    </base-loading>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
import BaseLoading from "@/resources/components/base-loading/index.vue";
@Component({
    name: "Define",
    components: {
        BaseLoading
    }
})
export default class Define extends Vue {
    loading = true;
    error = false;
    handleRetry(): void {
        this.$toast("执行重试动作");
    }
    mounted(): void {
        setTimeout(() => {
            this.loading = false;
            this.error = true;
        }, 1500);
    }
}
</script>

<style lang="scss" scoped>
p {
    text-align: center;
    margin-top: 200px;
}
</style>
