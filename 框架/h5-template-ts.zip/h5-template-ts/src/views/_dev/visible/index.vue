<template>
    <div>
        <h4>测试页面隐藏显示监听，请锁屏或隐藏浏览器后重新打开</h4>
        <h5>页面隐藏时间：{{ hideTime }}</h5>
        <base-page-visible @visible="show" @hidden="hidden"></base-page-visible>
    </div>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
import BasePageVisible from "@/resources/components/base-page-visible/index.vue";
@Component({
    name: "Define",
    components: {
        BasePageVisible
    }
})
export default class Define extends Vue {
    hideTime: number | Date = 0;
    show(): void {
        this.$toast.success("页面已加载");
    }
    hidden(): void {
        this.hideTime = new Date();
    }
}
</script>

<style lang="scss" scoped>
h4 {
    padding: 50px;
    font-size: 40px;
}
h5 {
    padding: 50px;
    font-size: 30px;
}
</style>
