<template>
    <div class="StackedLineChart">
        <base-charts :width="710" :height="500" :charts-option="ChartsOption"></base-charts>
    </div>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
import getRealPx from "@/utils/tools/get-realpx/index";
import BaseCharts from "@/resources/components/base-charts/index.vue";
@Component({
    components: {
        BaseCharts
    }
})
export default class EchartsLine extends Vue {
    ChartsOption = {};
    startValue = 3; //设置X轴从某天开始
    endValue = 5; //一次性展示5个
    /** 折线图用于提示 */
    tooltipData = ["10.01", "10.02", "10.03", "10.04", "10.05", "10.06", "10.07"];
    created(): void {
        this.ChartsOption = {
            legend: {
                icon: "roundRect", //  这个字段控制形状  类型包括 circle，rect ，roundRect，triangle，diamond，pin，arrow，none
                bottom: "0",
                itemWidth: getRealPx(10), // 设置宽度
                itemHeight: getRealPx(5), // 设置高度
                itemGap: getRealPx(24), // 设置间距
                data: ["全部订单", "物流订单", "自提订单"]
            },
            tooltip: {
                trigger: "axis",
                padding: [8, 10, 8, 10],
                axisPointer: {
                    type: "line",
                    lineStyle: {
                        color: "rgba(0, 0, 0, 0.65)"
                    }
                },
                // 自定义提示框的内容
                formatter: (params: any): string => {
                    let result = this.tooltipData[params[0].dataIndex] + "</br>";
                    params.forEach((el: any) => {
                        result += `${this.markDot(el.color)}${el.seriesName}：${el.data}</br>`;
                    });
                    return result;
                }
            },
            xAxis: {
                type: "category",
                data: ["10.01", "10.02", "10.03", "10.04", "10.05", "10.06", "10.07"],
                axisLine: {
                    lineStyle: {
                        color: "#999999"
                    }
                }
            },
            yAxis: {
                type: "value",
                axisLine: {
                    lineStyle: {
                        color: "#999999"
                    }
                }
            },
            dataZoom: [
                {
                    type: "inside", //slider表示有滑动块的，inside表示内置的
                    startValue: this.startValue, //从某个刻度轴开始
                    endValue: this.endValue, //一次性展示几个
                    filterMode: "none" //过滤数据
                }
            ],
            series: [
                {
                    name: "全部订单",
                    type: "line",
                    stack: "Total",
                    itemStyle: {
                        normal: {
                            color: "#707EFA",
                            lineStyle: {
                                color: "#707EFA"
                            }
                        }
                    },
                    symbol: "circle", //设定为实心点
                    symbolSize: getRealPx(8), //设定实心点的大小
                    data: [120, 132, 101, 134, 90, 230, 210]
                },
                {
                    name: "物流订单",
                    type: "line",
                    stack: "Total",
                    itemStyle: {
                        normal: {
                            color: "#6AD7A4", //折点颜色
                            lineStyle: {
                                color: "#6AD7A4"
                            }
                        }
                    },
                    symbol: "circle", //设定为实心点
                    symbolSize: getRealPx(8), //设定实心点的大小
                    data: [220, 182, 191, 234, 290, 330, 310]
                },
                {
                    name: "自提订单",
                    type: "line",
                    stack: "Total",
                    itemStyle: {
                        normal: {
                            color: "#FB9747",
                            lineStyle: {
                                color: "#FB9747"
                            }
                        }
                    },
                    symbol: "circle", //设定为实心点
                    symbolSize: getRealPx(8), //设定实心点的大小
                    data: [150, 232, 201, 154, 190, 330, 410]
                }
            ]
        };
    }
    // 生成大小一样样色不同的圆点
    markDot(color: string): string {
        let domHtml =
            '<span style="' +
            "display: inline-block;" +
            "margin-right: 8px;" +
            "margin-bottom: 2px;" +
            "width: 7px;" +
            "height: 2px;" +
            `background-color: ${color}` +
            '"></span>';
        return domHtml;
    }
}
</script>

<style scoped lang="scss">
.StackedLineChart {
    padding: 20px;
    font-size: 28px;
    color: #666666;
    background: #fff;
}
</style>
