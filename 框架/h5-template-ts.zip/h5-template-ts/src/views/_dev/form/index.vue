<template>
    <div class="form">
        <h1>form表单（设置表单的对齐方式）</h1>
        <van-cell>
            <base-form ref="form" key="1" :form="formConfig" :form-items="formItems1" :data.sync="form1"></base-form>
            <van-cell class="footer">
                <base-button block round type="danger">表单提交</base-button>
            </van-cell>
        </van-cell>

        <h1>form表单(单个表单表单项设置对齐方式)</h1>
        <base-input v-model="form5.file" v-bind="group5"></base-input>

        <h1>form表单(带表单校验)</h1>
        <van-cell>
            <base-form ref="form" key="2" :form-items="formItems2" :data.sync="form2"></base-form>
            <van-cell class="footer">
                <base-button block round type="danger" @click="submit2">表单提交</base-button>
            </van-cell>
        </van-cell>

        <h1>form表单(自定义上传样式)</h1>
        <base-form key="3" :form-items="formItems3" :data.sync="form3">
            <!-- 自定义上传样式 -->
            <template #uploader>
                <span>上传文件</span>
            </template>
        </base-form>

        <h1>form表单(使用单个表单控件)</h1>
        <base-uploader v-model="form4.file" v-bind="group4" :upload-end="uploadEnd">
            <!-- 通过默认插槽可以自定义上传区域的样式。 -->
            <template #uploader>
                <span>上传文件</span>
            </template>
        </base-uploader>
    </div>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
import { Form, Cell } from "vant";
import BaseForm from "@/resources/components/base-form/index.vue";
import BaseButton from "@/resources/components/base-button/index.vue";
import BaseInput from "@/resources/components/base-form/components/base-input/index.vue";
import BaseUploader from "@/resources/components/base-form/components/base-uploader/index.vue";
@Component({
    name: "form",
    components: {
        [Cell.name]: Cell,
        BaseForm,
        BaseButton,
        BaseInput,
        BaseUploader
    }
})
export default class form extends Vue {
    form1: any = {
        total: "",
        gender: "",
        datetime: "",
        region: [],
        file: [],
        checkbox: [],
        radio: "",
        switch: "",
        describe: ""
    };

    form2: any = {
        total: "",
        gender: "",
        datetime: "",
        region: [],
        file: [],
        checkbox: [],
        radio: "",
        switch: "",
        describe: ""
    };

    form3: any = {
        total: "",
        gender: "",
        datetime: "",
        region: [],
        file: [],
        checkbox: [],
        radio: "",
        switch: "",
        describe: ""
    };

    form4: any = {
        file: []
    };
    group4 = {
        label: "文件上传"
    };

    form5: any = {
        name: ""
    };
    group5 = {
        label: "姓名",
        labelAlign: "left", //表单项 label 对齐方式，可选值为 left center right
        inputAlign: "right", //输入框对齐方式，可选值为left center right
        errorMessageAlign: "right" //错误提示文案对齐方式，可选值为left center right
    };

    formConfig = {
        labelAlign: "left", //表单项 label 对齐方式，可选值为 left center right
        inputAlign: "left", //输入框对齐方式，可选值为left center right
        errorMessageAlign: "left" //错误提示文案对齐方式，可选值为left center right
    };

    get formItems1(): any[] {
        return [
            {
                groups: [
                    {
                        name: "total",
                        label: "总商品金额",
                        readonly: false,
                        inputType: "input"
                    },
                    {
                        name: "gender",
                        label: "性别",
                        inputType: "select",
                        options: [
                            { name: "男", value: "1" },
                            { name: "女", value: "2" }
                        ]
                    },
                    {
                        name: "datetime",
                        label: "日期",
                        inputType: "datetime",
                        options: {
                            type: "datetime"
                        }
                    },
                    {
                        name: "region",
                        label: "地区",
                        inputType: "area"
                    },
                    {
                        name: "file",
                        label: "文件上传",
                        inputType: "uploader",
                        uploadEnd: this.uploadEnd
                    },
                    {
                        name: "checkbox",
                        label: "复选框",
                        inputType: "checkbox",
                        options: [
                            { label: "复选框 1", value: "1" },
                            { label: "复选框 2", value: "2" }
                        ]
                    },
                    {
                        name: "radio",
                        label: "单选框",
                        inputType: "radio",
                        options: [
                            { label: "单选框1", value: "1" },
                            { label: "单选框2", value: "2" }
                        ]
                    },
                    {
                        name: "switch",
                        label: "开关",
                        inputType: "switch"
                    },
                    {
                        name: "describe",
                        label: "描述",
                        inputType: "textarea",
                        maxlength: "50", //输入的最大字符数
                        showWordLimit: true //是否显示字数统计，需要设置maxlength属性
                    }
                ]
            }
        ];
    }
    get formItems2(): any[] {
        return [
            {
                groups: [
                    {
                        name: "total",
                        label: "总商品金额",
                        readonly: false,
                        inputType: "input",
                        rules: [{ validator: this.validator }]
                    },
                    {
                        name: "gender",
                        label: "性别",
                        inputType: "select",
                        options: [
                            { name: "男", value: "1" },
                            { name: "女", value: "2" }
                        ],
                        labelAlign: "left",
                        rules: [{ required: true }]
                    },
                    {
                        name: "datetime",
                        label: "日期",
                        inputType: "datetime",
                        options: {
                            type: "datetime"
                        },
                        labelAlign: "left"
                    },
                    {
                        name: "region",
                        label: "地区",
                        inputType: "area",
                        labelAlign: "left"
                    },
                    {
                        name: "file",
                        label: "文件上传",
                        inputType: "uploader",
                        labelAlign: "left"
                    },
                    {
                        name: "checkbox",
                        label: "复选框",
                        inputType: "checkbox",
                        options: [
                            { label: "复选框 1", value: "1" },
                            { label: "复选框 2", value: "2" }
                        ],
                        labelAlign: "left"
                    },
                    {
                        name: "radio",
                        label: "单选框",
                        inputType: "radio",
                        options: [
                            { label: "单选框1", value: "1" },
                            { label: "单选框2", value: "2" }
                        ],
                        labelAlign: "left"
                    },
                    {
                        name: "switch",
                        label: "开关",
                        inputType: "switch",
                        labelAlign: "left"
                    },
                    {
                        name: "describe",
                        label: "描述",
                        inputType: "textarea",
                        maxlength: "50", //输入的最大字符数
                        showWordLimit: true, //是否显示字数统计，需要设置maxlength属性
                        rules: [{ required: true, message: "请填写用户名" }]
                    }
                ]
            }
        ];
    }
    get formItems3(): any[] {
        return [
            {
                groups: [
                    {
                        name: "total",
                        label: "总商品金额",
                        readonly: false,
                        inputType: "input"
                    },
                    {
                        name: "gender",
                        label: "性别",
                        inputType: "select",
                        options: [
                            { name: "男", value: "1" },
                            { name: "女", value: "2" }
                        ]
                    },
                    {
                        name: "datetime",
                        label: "日期",
                        inputType: "datetime",
                        options: {
                            type: "datetime"
                        }
                    },
                    {
                        name: "region",
                        label: "地区",
                        inputType: "area"
                    },
                    {
                        name: "file",
                        label: "文件上传",
                        inputType: "uploader"
                    },
                    {
                        name: "checkbox",
                        label: "复选框",
                        inputType: "checkbox",
                        options: [
                            { label: "复选框 1", value: "1" },
                            { label: "复选框 2", value: "2" }
                        ]
                    },
                    {
                        name: "radio",
                        label: "单选框",
                        inputType: "radio",
                        options: [
                            { label: "单选框1", value: "1" },
                            { label: "单选框2", value: "2" }
                        ]
                    },
                    {
                        name: "switch",
                        label: "开关",
                        inputType: "switch"
                    },
                    {
                        name: "describe",
                        label: "描述",
                        inputType: "textarea",
                        maxlength: "50", //输入的最大字符数
                        showWordLimit: true //是否显示字数统计，需要设置maxlength属性
                    }
                ]
            }
        ];
    }
    validator(val: any, rule: any): boolean {
        if (val == "") {
            rule.message = "请输入金额";
            return false;
        }
        if (!/(^[1-9]{1}[0-9]*$)|(^[0-9]*\.[0-9]{2}$)/.test(val)) {
            rule.message = "金额只能是数字";
            return false;
        }
        return true;
    }

    submit2(): void {
        (this.$refs.form as Form)
            .validate()
            .then((res) => {
                console.log("res", res);
            })
            .catch(() => {
                console.log("表单校验未通过");
            });
    }

    /** 上传完成回调 */
    uploadEnd(): void {
        console.log("上传完成回调 ");
    }
}
</script>

<style lang="scss" scoped>
.form {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    padding: 10px 20px 50px 20px;
    overflow-x: auto;
    h1 {
        font-size: 36px;
    }
}
</style>
