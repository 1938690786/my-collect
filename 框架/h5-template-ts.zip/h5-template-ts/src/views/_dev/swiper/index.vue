<template>
    <div class="swiper">
        <h1>3d流切换效果轮播图(不带圆角)</h1>
        <base-swiper :slide-data="slide" :swiper-option="swiperOption"></base-swiper>
        <h1>3d流切换效果轮播图(带圆角)</h1>
        <base-swiper :slide-data="slide" :swiper-option="swiperOption" :slide-border-radius="20"></base-swiper>
        <h1>普通切换效果轮播图轮播图</h1>
        <base-swiper :slide-data="slide" :swiper-option="swiperOption1" class="product-detatil-slide"></base-swiper>
        <h1>普通切换效果轮播图轮播图(自定义分页器)</h1>
        <base-swiper :slide-data="slide" :swiper-option="swiperOption2" class="product-detatil-slide"></base-swiper>
    </div>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
import BaseSwiper from "@/resources/components/base-swiper/index.vue";
@Component({
    name: "Swiper",
    components: {
        BaseSwiper
    }
})
export default class Swiper extends Vue {
    slide = [
        {
            type: "image",
            url: "https://img01.yzcdn.cn/vant/apple-1.jpg",
            hrefUrl: "/index"
        },
        {
            type: "image",
            url: "https://img01.yzcdn.cn/vant/apple-2.jpg",
            hrefUrl: "/business/index"
        },
        {
            type: "image",
            url: "https://img01.yzcdn.cn/vant/apple-1.jpg",
            hrefUrl: "/delivery"
        }
    ];

    swiperOption = {
        autoplay: false
    };
    swiperOption1 = {
        autoplay: false,
        effect: "slide"
    };
    swiperOption2 = {
        autoplay: false,
        effect: "slide",
        pagination: {
            el: ".swiper-pagination",
            type: "custom",
            renderCustom: (swiper: any, current: string | number, total: string | number): string => {
                return (
                    '<div  class="swiper-pagination-custom"><span class="swiper-pagination-custom-swiperPag">' +
                    current +
                    " / " +
                    total +
                    "</span></div>"
                );
            }
        }
    };
}
</script>

<style lang="scss" scoped>
.swiper {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    padding: 10px 0 50px 0;
    overflow-x: auto;
    h1 {
        font-size: 36px;
    }
    ::v-deep .product-detatil-slide {
        .swiper-slide {
            height: 650px;
        }
        /** 自定义swiper分页器样式 */
        .swiper-pagination-custom {
            display: flex;
            justify-content: flex-end;
            padding: 0 32px;
            bottom: 31px;
            &-swiperPag {
                padding: 0 25px;
                height: 36px;
                background: #000000;
                opacity: 0.6;
                border-radius: 18px;
                font-size: 24px;
                color: #ffffff;
                line-height: 36px;
            }
        }
    }
}
</style>
