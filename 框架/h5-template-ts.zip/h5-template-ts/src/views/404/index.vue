<template>
    <div>这是一个404页面</div>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
@Component({
    name: "Index",
    components: {}
})
export default class Index extends Vue {}
</script>

<style lang="scss" scoped></style>
