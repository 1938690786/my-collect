/**
 * deep clone an object
 *
 * @param {T} obj object to copy
 * @returns deep copied object
 */
const deepClone = function <T>(obj: T): any {
    if (obj == null || typeof obj != "object") return obj;
    else {
        if (obj instanceof Date) {
            const copy = new Date();
            copy.setTime(obj.getTime());
            return <T>(<unknown>copy);
        }

        if (obj instanceof Array) {
            const len = obj.length;
            const copy = new Array<T>();
            for (let i = 0; i < len; ++i) {
                copy[i] = deepClone(obj[i]);
            }
            return <T>(<unknown>copy);
        }

        if (obj instanceof Object) {
            const copy: T = <T>{};
            for (const attr in obj) {
                // eslint-disable-next-line no-prototype-builtins
                if ((obj as any).hasOwnProperty(attr)) copy[attr] = <T[Extract<keyof T, string>]>deepClone(obj[attr]);
            }
            return copy;
        }
    }

    throw new Error("Unable to copy this object");
};

export { deepClone };
