/**
 * 节流函数
 * @param fn 函数
 * @param delay 延迟，毫秒
 * @returns
 */
// eslint-disable-next-line no-unused-vars
export default function throttle(fn: (...args: any) => any, delay: number): () => void {
    let prev = 0;
    return function (this: any, ...args: any): void {
        const now = new Date().getTime();
        if (!prev || now - prev >= delay) {
            fn.apply(this, args);
            prev = new Date().getTime();
        }
    };
}
