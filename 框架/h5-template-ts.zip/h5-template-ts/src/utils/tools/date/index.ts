import dayjs from "dayjs";
import typeHelper from "@/utils/helper/type/index";
const dateHelper = {
    /**
     * Unix时间戳(秒/毫秒)转换日期
     * @param {Number } date 时间戳
     * @param {String} format 格式   如：YYYY-MM-DD
     * @returns  YYYY-MM-DD
     **/
    formatDate: (date: number | string | Date | dayjs.Dayjs, format = ""): string => {
        let DATE = "";
        //秒
        if ((typeHelper.isNumber(date) || typeHelper.isString(date)) && String(date).length === 10) {
            DATE = dayjs.unix(Number(date)).format(format);
        }
        //毫秒
        else if ((typeHelper.isNumber(date) || typeHelper.isString(date)) && String(date).length === 13) {
            DATE = dayjs(Number(date)).format(format);
        } else {
            DATE = dayjs(date).format(format);
        }
        return DATE;
    },
    /**
     * 字符串时间转时间戳
     * @param {String | Date } date 日期
     * @returns
     */
    unix: (date: string | number | Date | dayjs.Dayjs): number => {
        return dayjs(date).unix();
    }
};
export default dateHelper;
