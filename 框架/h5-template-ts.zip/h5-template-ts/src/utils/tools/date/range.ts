/*
 * @Description:
 * @Autor: hanxinxin
 * @Date: 2021-04-19 15:32:49
 * @LastEditors: hanxinxin
 * @LastEditTime: 2021-04-20 09:24:12
 * @FilePath: \h5-template\src\utils\tools\date\range.ts
 */
export default function (n: number, m: number, polyfill = false, unit = ""): string[] {
    const arr = [];
    for (let i = n; i <= m; i++) {
        const value = (polyfill && i < 10 ? "0" + i : i) + unit;
        arr.push(value);
    }
    return arr;
}
