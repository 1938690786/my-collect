/* 获取url链接中的参数
 * @Author: hanxinxin
 * @Date: 2021-04-26 09:46:43
 * @Last Modified by: hanxinxin
 * @Last Modified time: 2021-09-23 14:16:49
 */

export default function getUrlkey(name: string): string {
    // const arr = new RegExp(`[?|&]${name}=([^&;]+?)(&|#|;|$)`).exec(location.href) || [""];
    // if (arr.length && arr[1]) {
    //     return decodeURIComponent(arr[1].replace(/\+/g, "").replace(/%20/g, "")) || "";
    // } else {
    //     return "";
    // }
    const url = decodeURIComponent(window.location.search);
    const reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    const r = url.substr(1).match(reg);
    if (r != null) return unescape(r[2]);
    return "";
}
