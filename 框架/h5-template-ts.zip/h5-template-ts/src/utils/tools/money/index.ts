/**
 * 将数值四舍五入(保留2位小数)后格式化成金额形式
 * @param num 数值(Number或者String)
 * @param digit 保留小数点几位
 * @return 金额格式的字符串,如'1,234,567.45'
 */
export function formatMoney(num: number | string, digit = 2): string {
    num = Number(num.toString().replace(/\$|,/g, ""));
    if (isNaN(num)) {
        num = "0";
    }
    // 最大支持11位小数
    if (digit > 11) {
        return "0.00";
    }
    // 绝对值
    const sign = Number(num) === (num = Math.abs(Number(num)));
    let cents: any = null;
    num = Math.floor(num * Math.pow(10, digit) + 0.50000000001);
    if (digit > 0) {
        // 小数位
        cents = num % Math.pow(10, digit);
        cents = ("00000000000" + num).substr(-digit);
    }
    num = Math.floor(num / Math.pow(10, digit)).toString();
    for (let i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
        num = num.substring(0, num.length - (4 * i + 3)) + "," + num.substring(num.length - (4 * i + 3));
    }
    if (cents) {
        return (sign ? "" : "-") + num + "." + cents;
    } else {
        return (sign ? "" : "-") + num;
    }
}
