/**
 * 防抖
 * @param fn
 * @param delay
 * @returns {function(...[*]=): void}
 */
export default function debounce(fn: () => any, delay: number): () => void {
    let timer: number | undefined;
    return function (this: any, ...args: any): void {
        timer && clearTimeout(timer);
        timer = setTimeout(() => {
            fn.apply(this, args);
        }, delay);
    };
}
