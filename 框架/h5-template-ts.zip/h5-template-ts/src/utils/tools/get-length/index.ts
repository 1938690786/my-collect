/* 获得字符串实际长度
 * @Author: hanxinxin
 * @Date: 2021-04-26 09:47:04
 * @Last Modified by:   hanxinxin
 * @Last Modified time: 2021-04-26 09:47:04
 */

/**
 * 获得字符串实际长度，中文2，英文1
 * @param str 要获得长度的字符串
 * @returns
 */
function getLength(str: string | number): number {
    let realLength = 0;
    const len = str.toString().length;
    let charCode = -1;
    for (let i = 0; i < len; i++) {
        charCode = str.toString().charCodeAt(i);
        if (charCode >= 0 && charCode <= 128) realLength += 1;
        else realLength += 2;
    }
    return realLength;
}

export { getLength };
