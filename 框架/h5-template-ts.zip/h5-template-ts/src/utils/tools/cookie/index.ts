/*
 * @Description:
 * @Autor: hanxinxin
 * @Date: 2021-04-19 15:32:49
 * @LastEditors: hanxinxin
 * @LastEditTime: 2021-04-20 09:23:30
 * @FilePath: \h5-template\src\utils\tools\cookie\index.ts
 */
function setCookie(data: any): void {
    let expires: any = "";
    if (data.day) {
        const d = new Date();
        d.setTime(d.getTime() + data.day * 24 * 60 * 60 * 1000);
        expires = "expires=" + d.toUTCString();
    }
    document.cookie = data.name + "=" + data.value + ";" + expires + ";path=/";
}

function getCookie(name: string): any {
    let arr;
    const reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");

    if ((arr = document.cookie.match(reg))) return arr[2];
    else return undefined;
}

export { setCookie, getCookie };
