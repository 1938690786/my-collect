/* 操作storage
 * @Author: hanxinxin
 * @Date: 2021-04-20 18:17:48
 * @Last Modified by: hanxinxin
 * @Last Modified time: 2021-12-21 17:13:35
 */

import validatorHelper from "@/utils/helper/validator";

const TOKEN_KEY = "SSY_AGENT_TOKEN"; //token存储key
const TOKEN_EXPIRE = 172800; //token有效期，单位秒

const storageUtil = {
    get: (key: string): string => {
        return String(window.localStorage.getItem(key));
    },
    set: (key: string, value: any): void => {
        return window.localStorage.setItem(key, typeof value !== "string" ? JSON.stringify(value) : value);
    },
    del: (key: string): void => {
        return window.localStorage.removeItem(key);
    },
    clear: (): void => {
        return window.localStorage.clear();
    }
};

interface TokenInfo {
    token: string;
    expire: number;
}

const storage = {
    /**
     * 设置token
     * @param token
     */
    setToken: (token: string): void => {
        const info: TokenInfo = {
            token,
            expire: new Date().getTime() + TOKEN_EXPIRE * 1000
        };
        storageUtil.set(TOKEN_KEY, info);
    },
    /**
     * 获取token
     * @returns
     */
    getToken: (): string => {
        const infoStr = storageUtil.get(TOKEN_KEY);
        if (!validatorHelper.isStrExist(infoStr)) {
            return "";
        }
        const info: TokenInfo = JSON.parse(infoStr);
        const now = new Date().getTime();
        if (now >= info.expire) {
            storageUtil.del(TOKEN_KEY);
            return "";
        }
        return info.token;
    },

    /** 删除token */
    delToken: (): void => {
        storageUtil.del(TOKEN_KEY);
    },
    /** 清除token */
    clear: (): void => {
        storageUtil.clear();
    }
};

export default storage;
