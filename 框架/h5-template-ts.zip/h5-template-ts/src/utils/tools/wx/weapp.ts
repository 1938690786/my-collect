/**
 * 创建微信开放标签
 * @param htmlStr，开放标签包裹的content的字符串
 * @param domId，包裹开放标签的dom的ID
 * @param launchId，开放标签的ID
 * @param username，微信小程序的原始ID
 * @param path，微信小程序的跳转路径
 */
export default function createWeApp(
    htmlStr: string,
    domId: string,
    launchId: string,
    username: string,
    path: string
): void {
    const script = document.createElement("script");
    script.type = "text/wxtag-template";
    script.text = htmlStr;
    const html = `<wx-open-launch-weapp username="${username}" id="${launchId}" path="${path}">${script.outerHTML}</wx-open-launch-weapp>`;
    setTimeout(() => {
        const wrapper = document.getElementById(`${domId}`);
        if (!wrapper) {
            console.log(`${domId}的wrapper未找到`);
            return;
        }
        wrapper.innerHTML = html;
        const wxDom = document.getElementById(`${launchId}`);
        if (!wxDom) {
            console.log(`${launchId}的开放标签id未找到`);
            return;
        }
        wxDom.addEventListener("launch", () => {
            console.log("开放标签渲染成功");
        });
        wxDom.addEventListener("error", (e) => {
            console.log("开放标签事件监听出错：", e);
        });
    }, 200);
}
