/* 格式化图片
 * @Author: hanxinxin
 * @Date: 2021-04-26 09:47:21
 * @Last Modified by:   hanxinxin
 * @Last Modified time: 2021-04-26 09:47:21
 */
/**
 * 格式化图片
 * @param src
 * @param width
 * @param height
 * @returns
 */
export function formatImage(src: string, width: number, height: number): string {
    // 不处理非图片服务器的图片
    if (!src || src.indexOf("71360.com") === -1) return src;

    // 将图片上已有的?后面的参数全部截取掉
    src = src.replace(/\?.+/g, "");

    const params = [];
    if (width) {
        params.push("w=" + width);
    }
    if (height) {
        params.push("h=" + height);
    }

    return src + (src.lastIndexOf("?") === -1 ? "?" : "&") + params.join("&");
}
