import { v4 as uuidv4 } from "uuid";

/**
 * 生成uuid
 * @returns string
 */
export default function uuid(): string {
    return uuidv4();
}
