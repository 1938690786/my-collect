/* 项目登录逻辑
 * @Author: hanxinxin
 * @Date: 2021-04-20 19:20:10
 * @Last Modified by: hanxinxin
 * @Last Modified time: 2021-12-16 21:18:41
 */
import router from "@/packages/vue-router/index";
import getUrlkey from "@/utils/tools/get-urlkey/index";
import { autoLogin } from "@/config/apis/user";
import session from "../session";
import wxauth from "@/utils/tools/wx/wxauth";
import { Toast } from "vant";
import uaHelper from "@/utils/helper/ua";
import storage from "../storage";

let isDoLogin = false;

/** 监听自动登录状态 */
function watchLogin(): void {
    const t = setInterval(() => {
        if (!isDoLogin) {
            Toast.clear();
            clearInterval(t);
        } else {
            Toast({
                type: "loading",
                message: "登录中...",
                duration: 0
            });
        }
    }, 20);
}
export function login(): void {
    /** 缓存回调地址到session */
    session.setFromPath(location.href);
    /**
     * 阻止自动登录情况
     * 1、已经在登录中状态
     * 2、已经跳转到验证码登录
     */
    if (getUrlkey("verlogin") === "true" || isDoLogin) {
        return;
    }
    /** 非微信浏览器直接跳转登录页，进行手机+验证码登录，仅能支持已注册用户登录 */
    if (!uaHelper.isWechat) {
        router.replace({
            name: "login",
            query: {
                verlogin: "true"
            }
        });
        return;
    }
    /** 删除当前token */
    storage.delToken();

    /** 获取微信授权带回的code */
    const code = getUrlkey("code");

    /** 获取session中缓存的微信code和授权次数 */
    const sessionCode = session.getWxCode();

    /** 授权循环次数达到上限，直接到错误页 */
    if (sessionCode?.count === 3) {
        router.replace({
            name: "business-error",
            query: {
                message: ""
            }
        });
        return;
    }

    /** 不存在微信code的或者code重复，直接去拉起微信授权 */
    if (!code || code === sessionCode?.code) {
        wxauth();
        return;
    }

    if (!sessionCode) {
        /** 如果不存在sessioncode，存入第一次 */
        session.setWxCode({ code, count: 1 });
    } else {
        /** 增加sessionCode次数 */
        session.setWxCode({ code, count: ++sessionCode.count });
    }
    watchLogin();
    isDoLogin = true;
    autoLogin({
        code,
        brand_id: "",
        invite_code: ""
    })
        .then(() => {
            loginJump();
        })
        .catch(() => {
            router.replace({
                name: "login",
                query: {
                    verlogin: "true"
                }
            });
        })
        .finally(() => {
            isDoLogin = false;
        });
}

/** 登录成功后跳转 */
export function loginJump(): void {
    let url = "/index";
    if (router.options.base) {
        url = `/${router.options.base}${url}`;
    }
    const sessionUrl = session.getFormPath();
    location.href = sessionUrl || url;
}
