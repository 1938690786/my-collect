/* eslint-disable no-unused-vars,@typescript-eslint/no-unused-vars */
import uaHelper from "@/utils/helper/ua";
import Vue from "vue";
const vm = new Vue();
class NativeBridge {
    // eslint-disable-next-line prettier/prettier,@typescript-eslint/no-empty-function
    constructor() { }

    handleMethods(name: string): void;
    handleMethods(name: string, callback: (res: any) => void): void;
    handleMethods(name: string, params: any): void;
    handleMethods(name: string, params: any, callback: (res: any) => void): void;

    handleMethods(name: string, params?: any, callback?: (res: any) => void): void {
        try {
            // 解决如果二个参数是 callback 的情况，变量交换
            if (typeof params === "function" && !callback) {
                callback = params;
                params = {};
            }

            const functionName = `${name}${new Date().getTime()}`;
            params.callback = functionName;

            if (uaHelper.isAndroidApp || uaHelper.isIosApp) {
                if (callback) {
                    // 注册回调
                    Reflect.defineProperty(window, functionName, {
                        enumerable: false,
                        value: function (res: any) {
                            callback && callback(res);
                            Reflect.deleteProperty(window, functionName);
                        }
                    });
                }
                console.log(`调用${name}方法,参数${JSON.stringify(params)}`);
                if (uaHelper.isAndroidApp) {
                    (window as any).syy_app_h5[name](JSON.stringify(params));
                } else if (uaHelper.isIosApp) {
                    // ios 将方法名当作参数传递
                    params.key = name;
                    (window as any).webkit.messageHandlers.syy_app_h5.postMessage(params);
                }
            } else {
                console.warn("此功能需要访问 APP 才能使用");
            }
        } catch (e) {
            console.log(`调用${name}方法失败,参数${JSON.stringify(params)}`, e);
            this.awakeAppUpdate();
        }
    }

    registerWindowEvent(name: string, callback: () => void): void;
    registerWindowEvent(name: string, callback: () => void, autoDestoryed: boolean): void;

    registerWindowEvent(name: string, callback: (res?: any) => void, autoDestoryed = true): void {
        try {
            Reflect.defineProperty(window, name, {
                enumerable: false,
                value: function (res: any) {
                    callback(res);
                    autoDestoryed && Reflect.deleteProperty(window, name);
                }
            });
        } catch (e) {
            console.log(e);
        }
    }

    /**
     * 唤起APP强制更新弹窗
     */
    private awakeAppUpdate(): void {
        vm.$dialog.alert({
            title: "发现新版本",
            message: "请前往应用商店进行更新",
            confirmButtonText: "我知道了"
        });
    }
}

export default new NativeBridge();
Vue.prototype.$nativeApp = new NativeBridge();
