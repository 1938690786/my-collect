/* 操作浮点运算，防止精度丢失
 * @Author: hanxinxin
 * @Date: 2021-04-29 11:28:59
 * @Last Modified by: hanxinxin
 * @Last Modified time: 2021-07-28 23:42:00
 */

import Big from "big.js";
/**
 * 浮点运算
 */
const float = {
    //加法
    plus: (num1: number, num2: number, point = 2): number => {
        Big.DP = point;
        return new Big(num1).plus(new Big(num2)).toNumber();
    },
    //减法
    min: (num1: number, num2: number, point = 2): number => {
        Big.DP = point;
        return new Big(num1).minus(new Big(num2)).toNumber();
    },
    //乘法
    tim: (num1: number, num2: number, point = 2): number => {
        Big.DP = point;
        return new Big(num1).times(new Big(num2)).toNumber();
    },
    //除法
    div: (num1: number, num2: number, point = 2): number => {
        Big.DP = point;
        return new Big(num1).div(new Big(num2)).toNumber();
    },
    //取余数
    mod: (num1: number, num2: number, point = 2): number => {
        Big.DP = point;
        return new Big(num1).mod(new Big(num2)).toNumber();
    },
    //取绝对值
    abs: (num: number): number => {
        return new Big(num).abs().toNumber();
    },
    //补全小数点位数
    fix: (num: number, point: number): string => {
        return new Big(num).toFixed(point);
    }
};

export default float;
