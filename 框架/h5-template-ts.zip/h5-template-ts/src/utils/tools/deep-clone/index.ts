function deepClone<T>(sourceData: T): T {
    let cloneData: any;

    if (cloneData instanceof Date) {
        /** 时间类型 */
        cloneData = new Date(sourceData as unknown as Date);
    } else if (cloneData instanceof RegExp) {
        /** 正则类型 */
        cloneData = new RegExp(sourceData as unknown as RegExp);
    } else if (sourceData === null || typeof sourceData !== "object") {
        cloneData = sourceData;
    } else {
        if (Array.isArray(sourceData)) {
            cloneData = [...sourceData];
        } else {
            cloneData = {};
            for (const key in sourceData) {
                cloneData[key] = deepClone(sourceData[key]);
            }
        }
    }
    return cloneData;
}

export default deepClone;
