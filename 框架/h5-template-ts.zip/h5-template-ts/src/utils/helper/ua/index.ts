const userAgent = navigator.userAgent;
const uaHelper = {
    /** 微信浏览器 */
    isWechat: /MicroMessenger/i.test(userAgent) && /miniprogram/i.test(userAgent) === false,
    /** 微信小程序 */
    isWemp: /MicroMessenger/i.test(userAgent) && /miniprogram/i.test(userAgent),
    /** 安卓 */
    isAndroid: /(Android)/.test(userAgent),
    /** 苹果 */
    isIos: /(iPhone|iPad|iPod|iOS)/.test(userAgent),
    /** 安卓app */
    isAndroidApp: /android_syy_app/.test(userAgent),
    /** 苹果app */
    isIosApp: /ios_syy_app/.test(userAgent),
    /** app */
    inApp: /android_syy_app/.test(userAgent) || /ios_syy_app/.test(userAgent)
};

export default uaHelper;
