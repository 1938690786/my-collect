import dayjs from "dayjs";
const dateHelper = {
    /**
     * Date对象转换日期
     * @param {Number } date Date对象
     * @param {String} format 格式   如：【YYYY-MM-DD (2020-09-08)、YYYY-MM-DD HH:mm:ss (2020-09-08 13:47:12)】
     * @returns
     **/
    formatDate: (date: Date | dayjs.Dayjs, format = ""): string => {
        return dayjs(date).format(format);
    },

    /**
     * Unix时间戳(秒/毫秒)转换日期
     * @param {Number } timestamp 时间戳
     * @param {String} format 格式   如：【YYYY-MM-DD (2020-09-08)、YYYY-MM-DD HH:mm:ss (2020-09-08 13:47:12)】
     * @returns
     **/
    formatDateTimeStamp: (timestamp: number, format = ""): string => {
        //秒
        if (String(timestamp).length === 10) {
            timestamp = timestamp * 1000;
        }
        return dayjs(timestamp).format(format);
    },

    /**
     * 字符串时间转时间戳
     * @param {String | Date } date 日期
     * @returns
     */
    unix: (date: string | number | Date | dayjs.Dayjs): number => {
        return dayjs(date).unix();
    }
};
export default dateHelper;
