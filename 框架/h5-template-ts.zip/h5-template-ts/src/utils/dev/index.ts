export * from "./global-mount-vue-component";
