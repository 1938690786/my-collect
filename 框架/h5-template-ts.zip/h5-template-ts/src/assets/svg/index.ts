const context = require.context(".", false, /\.svg$/);
const requireAll = (requireContext: any): void => {
    return requireContext.keys().map(requireContext);
};
requireAll(context);
