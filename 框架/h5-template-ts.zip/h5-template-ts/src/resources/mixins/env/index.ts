import { Vue, Component } from "vue-property-decorator";

/**Mixin：环境*/
@Component
export default class Env extends Vue {
    get isDev(): boolean {
        return process.env.domain === "local";
    }
}
