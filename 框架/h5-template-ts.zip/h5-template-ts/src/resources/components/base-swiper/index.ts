export interface swiperOptionParams {
    /**  可选选项，自动滑动 */
    autoplay?: boolean;
    /** 循环模式*/
    loop?: boolean;
    /**
     * slide的切换效果，默认为"slide"（位移切换），可设置为'slide'（普通切换、默认）,"fade"（淡入）"cube"（方块）"coverflow"（3d流）"flip"（3d翻转）。
     */
    effect?: string;
    /**
     * cover flow是类似于苹果将多首歌曲的封面以3D界面的形式显示出来的方式。coverflow效果参数，可选值：
     * rotate	50	slide做3d旋转时Y轴的旋转角度
     * stretch	0	每个slide之间的拉伸值，越大slide靠得越紧。5.3.6 后可使用%百分比
     * depth	100	slide的位置深度。值越大z轴距离越远，看起来越小。
     * modifier	1	depth和rotate和stretch的倍率，相当于depth*modifier、rotate*modifier、stretch*modifier，值越大这三个参数的效果越明显。
     * slideShadows	true	是否开启slide阴影
     */
    coverflowEffect?: any;
}
