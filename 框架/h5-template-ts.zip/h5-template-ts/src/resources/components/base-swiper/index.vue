<template>
    <div v-if="active" id="BaseSwiper" class="base-swiper">
        <swiper :options="options" @ready="handleSwiperReadied">
            <swiper-slide
                v-for="(item, idx) in slideData"
                :key="idx"
                :style="{
                    ...slideBorderRadiusVar,
                    width: options.effect === 'coverflow' ? '90%' : ''
                }"
            >
                <!-- 图片 -->
                <template v-if="item.type === 'image'">
                    <img :src="item.url" :data-idx="idx" />
                </template>
                <!-- 视频 -->
            </swiper-slide>
            <div slot="pagination" class="swiper-pagination"></div>
        </swiper>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { swiper, swiperSlide } from "vue-awesome-swiper";
import "swiper/dist/css/swiper.css";
import { swiperOptionParams } from "./index";

@Component({
    name: "TemplateName",
    components: {
        swiper,
        swiperSlide
    }
})
export default class TemplateName extends Vue {
    /**
     * @param {array} 显示的数据
     */
    @Prop({
        type: Array,
        required: true,
        default: []
    })
    slideData!: any;

    /**
     * @param {string}  slide圆角
     */
    @Prop({
        type: [String, Number],
        default: 0
    })
    slideBorderRadius?: string | number;

    get slideBorderRadiusVar(): any {
        return { "--slideBorderRadius": this.slideBorderRadius + "px" };
    }

    active = true;
    /**
     * @param {Object} swiper配置
     */
    @Prop({
        type: Object,
        default: null
    })
    swiperOption?: swiperOptionParams;

    swiper = null;
    //默认swiper配置项
    defaultSwiperOption = {
        /**
         * 使用分页器导航。分页器可使用小圆点样式（默认）、分式样式或进度条样式。
         */
        pagination: {
            el: ".swiper-pagination",
            clickable: true
        },

        paginationHide: false,
        autoplay: true, //可选选项，自动滑动
        loop: true, //循环模式
        effect: "coverflow", //slide的切换效果，默认为"slide"（位移切换），可设置为'slide'（普通切换、默认）,"fade"（淡入）"cube"（方块）"coverflow"（3d流）"flip"（3d翻转）。
        slidesPerView: "auto", //根据slide的宽度自动调整展示数量。此时需要设置slide的宽度，
        centeredSlides: true, //设定为true时，active slide会居中，而不是默认状态下的居左。
        spaceBetween: 50, //slide之间设置距离（单位px）。
        // paginationClickable: true, //点击分页器 进行切换swiper
        slideToClickedSlide: true,
        /**
         * cover flow是类似于苹果将多首歌曲的封面以3D界面的形式显示出来的方式。coverflow效果参数，可选值：
         * rotate	50	slide做3d旋转时Y轴的旋转角度
         * stretch	0	每个slide之间的拉伸值，越大slide靠得越紧。5.3.6 后可使用%百分比
         * depth	100	slide的位置深度。值越大z轴距离越远，看起来越小。
         * modifier	1	depth和rotate和stretch的倍率，相当于depth*modifier、rotate*modifier、stretch*modifier，值越大这三个参数的效果越明显。
         * slideShadows	true	是否开启slide阴影
         */
        coverflowEffect: {
            rotate: 12,
            stretch: 10,
            depth: 30,
            modifier: 2,
            slideShadows: false
        },
        //自定义活跃的 slide 类名
        slideActiveClass: "my-active-slide",
        on: {
            tap: (event: any): void => {
                //可通过this访问当前vue实例
                event = event || window.event;
                const ele = event.target;
                const idx = ele.getAttribute("data-idx");
                if (idx) {
                    const URL = this.slideData[idx].hrefUrl;
                    URL && this.$router.push(URL);
                }
            }
        }
    };

    get options(): swiperOptionParams {
        if (this.swiperOption) {
            const coverflowEffect = this.defaultSwiperOption.coverflowEffect;
            const coverflowEffectProps = this.swiperOption.coverflowEffect || {};
            const newCoverflowEffect = Object.assign(coverflowEffect, coverflowEffectProps);
            this.swiperOption.coverflowEffect = newCoverflowEffect;
        }
        if (this.slideData.length < 2) {
            this.defaultSwiperOption.loop = false;
        }
        return Object.assign(this.defaultSwiperOption, this.swiperOption || {});
    }

    // `@ready` event will emit when the Swiper instance mounted
    handleSwiperReadied(swiper: any): void {
        this.swiper = swiper;
    }

    deactivated(): void {
        this.active = false;
    }

    activated(): void {
        this.active = true;
    }
}
</script>

<style lang="scss" scoped>
.base-swiper {
    .swiper-container {
        width: 100%;
    }

    .swiper-slide {
        width: 100%;
        height: 280px;
        font-size: 0;
        border-radius: var(--slideBorderRadius);
        overflow: hidden;
        & > a {
            display: block;
            width: 100%;
            height: 100%;
        }
        img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    }

    /** 分页器 */
    ::v-deep .swiper-pagination-bullet {
        width: 10px;
        height: 10px;
        background: #ffffff;
        opacity: 0.5;
        border-radius: 50%;
    }
    ::v-deep .swiper-pagination-bullet-active {
        opacity: 1;
        background: #ffffff;
    }
}
</style>
