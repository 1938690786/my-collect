### 组件名称：表格组件

### 场景

### API

#### Props

| 参数         | 说明                                                              | 类型   | 默认值 |
| ------------ | ----------------------------------------------------------------- | ------ | ------ |
| slideData    | 显示的数据                                                        | Array  | []     |
| swiperOption | 外部传入的 swiper 基本配置,具体参数详见下方 swiperOption 参数说明 | object | {}     |

#### swiperOption 参数说明

| 参数              | 说明                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | 类型             | 默认值    |
| ----------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------- | --------- |
| autoplay          | 自动滑动,true:开启自动滑动模式，false:不开启自动滑动模式                                                                                                                                                                                                                                                                                                                                                                                                                   | Boolean          | true      |
| loop              | 循环模式,true:开启循环模式模式，false:不开启循环模式模式                                                                                                                                                                                                                                                                                                                                                                                                                   | Boolean          | true      |
| effect            | slide 的切换效果,可选值'slide'（普通切换、默认）,"fade"（淡入）"cube"（方块）"coverflow"（3d 流）"flip"（3d 翻转）。                                                                                                                                                                                                                                                                                                                                                       | String           | coverflow |
| slideBorderRadius | slide 圆角                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | String or Number | 0         |
| coverflowEffect   | coverflowEffect 效果参数，可选值：<br> rotate (默认值：50)，slide 做 3d 旋转时 Y 轴的旋转角度<br> stretch (默认值：0)，每个 slide 之间的拉伸值，越大 slide 靠得越紧。5.3.6 后可使用%百分比 <br>depth (默认值：100)，slide 的位置深度。值越大 z 轴距离越远，看起来越小。 <br>modifier (默认值：1)，depth 和 rotate 和 stretch 的倍率，相当于 depth*modifier、rotate*modifier、stretch\*modifier，值越大这三个参数的效果越明显。 <br>slideShadows， true 是否开启 slide 阴影 | Object           |           |

#### Events

| 事件名 | 说明 | 回调参数 |
| ------ | ---- | -------- |

#### 用法

```html
<template>
    <div class="swiper">
        <h1>轮播图</h1>
        <base-swiper :slide-data="slide"></base-swiper>
    </div>
</template>
```

```ts
<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { swiper, swiperSlide } from "vue-awesome-swiper";
import "swiper/dist/css/swiper.css";
@Component({
    name: "TemplateName",
    components: {
        swiper,
        swiperSlide
    }
})
export default class TemplateName extends Vue {
    /**
     * @param {array} 显示的数据
     */
    @Prop({
        type: Array,
        required: true,
        default: []
    })
    slideData!: any;

    swiperOption = {
        /**
         * 使用分页器导航。分页器可使用小圆点样式（默认）、分式样式或进度条样式。
         */
        pagination: {
            el: ".swiper-pagination",
            clickable: true
        },
        autoplay: true, //可选选项，自动滑动
        loop: true, //循环模式
        effect: "coverflow", //slide的切换效果，默认为"slide"（位移切换），可设置为'slide'（普通切换、默认）,"fade"（淡入）"cube"（方块）"coverflow"（3d流）"flip"（3d翻转）。
        slidesPerView: "auto", //根据slide的宽度自动调整展示数量。此时需要设置slide的宽度，
        centeredSlides: true, //设定为true时，active slide会居中，而不是默认状态下的居左。
        spaceBetween: 50, //slide之间设置距离（单位px）。
        paginationClickable: true,
        slideToClickedSlide: true,
        /**
         * cover flow是类似于苹果将多首歌曲的封面以3D界面的形式显示出来的方式。coverflow效果参数，可选值：
         * rotate	50	slide做3d旋转时Y轴的旋转角度
         * stretch	0	每个slide之间的拉伸值，越大slide靠得越紧。5.3.6 后可使用%百分比
         * depth	100	slide的位置深度。值越大z轴距离越远，看起来越小。
         * modifier	1	depth和rotate和stretch的倍率，相当于depth*modifier、rotate*modifier、stretch*modifier，值越大这三个参数的效果越明显。
         * slideShadows	true	是否开启slide阴影
         */
        coverflowEffect: {
            rotate: 12,
            stretch: 10,
            depth: 30,
            modifier: 2,
            slideShadows: false
        }
    };
}
</script>
```

```scss
<style lang="scss" scoped>
.base-swiper {
    .swiper-container {
        width: 100%;
    }
    ::v-deep .swiper-pagination-bullet {
        width: 10px;
        height: 10px;
        background: #ffffff;
        opacity: 0.5;
        border-radius: 50%;
    }

    ::v-deep .swiper-pagination-bullet-active {
        opacity: 1;
        background: #ffffff;
    }
    .swiper-slide {
        width: 80%;
        height: 280px;
        font-size: 0;
        border-radius: 24px;
        overflow: hidden;
        img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    }
}
</style>
```
