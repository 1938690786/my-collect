<template>
    <div class="base-cell-warpper" :style="cellConfig.wrapperClass">
        <slot name="default-content"></slot>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { CardProp } from "/#/base";

@Component({
    name: "wrapper"
})
export default class Wrapper extends Vue {
    @Prop({
        type: [Object]
    })
    cellConfig?: CardProp;
}
</script>

<style lang="scss" scoped>
.base-cell-warpper {
    border-radius: 12px;
    background-color: #fff;
    overflow: hidden;
}
</style>
