<template>
    <van-dialog
        v-model="visible"
        v-bind="$attrs"
        class="base-dialogform_wrapper"
        :show-cancel-button="showCancelButton"
        :before-close="onBeforeClose"
    >
        <van-form ref="form" v-bind="form">
            <template v-for="(item, index) in formItems">
                <van-cell-group :key="index" :border="false">
                    <template v-for="group in item.groups">
                        <base-input
                            v-if="!group.inputType || group.inputType === 'input'"
                            :key="group.name"
                            v-model.trim="model[group.name]"
                            v-bind="group"
                        ></base-input>
                        <base-select
                            v-if="group.inputType === 'select'"
                            :key="group.name"
                            v-model="model[group.name]"
                            v-bind="group"
                        ></base-select>
                        <base-datetime
                            v-if="group.inputType === 'datetime'"
                            :key="group.name"
                            v-model="model[group.name]"
                            v-bind="group"
                        ></base-datetime>
                        <base-area
                            v-if="group.inputType === 'area'"
                            :key="group.name"
                            v-model="model[group.name]"
                            v-bind="group"
                        ></base-area>
                        <base-uploader
                            v-if="group.inputType === 'uploader'"
                            :key="group.name"
                            v-model="model[group.name]"
                            v-bind="group"
                        ></base-uploader>
                        <template v-if="group.inputType === 'slot'">
                            <slot :name="group.name" :form-item="group" :model="model"></slot>
                        </template>
                    </template>
                </van-cell-group>
            </template>
        </van-form>
    </van-dialog>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from "vue-property-decorator";
import { Form, Dialog, Cell, CellGroup } from "vant";
import BaseInput from "@/resources/components/base-form/components/base-input/index.vue";
import BaseSelect from "@/resources/components/base-form/components/base-select/index.vue";
import BaseDatetime from "@/resources/components/base-form/components/base-datetime-picker/index.vue";
import BaseArea from "@/resources/components/base-form/components/base-area-picker/index.vue";
import BaseUploader from "@/resources/components/base-form/components/base-uploader/index.vue";
@Component({
    components: {
        [Form.name]: Form,
        [Dialog.name]: Dialog.Component,
        [Cell.name]: Cell,
        [CellGroup.name]: CellGroup,
        BaseInput,
        BaseSelect,
        BaseDatetime,
        BaseArea,
        BaseUploader
    }
})
export default class BaseDialogForm extends Vue {
    @Prop({
        type: Object,
        required: true,
        default: () => {
            return {};
        }
    })
    data!: any;
    // form配置
    @Prop({
        default: () => {
            return {};
        }
    })
    form?: any;

    // form-item配置
    @Prop({
        type: Array,
        default: () => {
            return [];
        }
    })
    formItems?: any[];

    @Prop({
        default: true
    })
    showCancelButton?: boolean;

    visible = false;
    model = {};

    @Watch("visible", { immediate: true })
    onWatchVisible(newVal: boolean): void {
        // newVal && (this.model = deepClone(this.data));
        newVal && (this.model = this.data);
    }

    show(): void {
        this.visible = true;
    }
    hide(): void {
        this.visible = false;
    }
    onBeforeClose(action: string, done: any): void {
        if (action === "confirm") {
            (this.$refs.form as Form)
                .validate()
                .then(() => {
                    this.$emit("on-form", {
                        event: action,
                        model: this.model
                    });
                    done();
                    this.resetValidation();
                })
                .catch(() => {
                    done(false);
                });
            return;
        }
        this.$emit("on-form", {
            event: action,
            model: this.model
        });
        done();
        this.resetValidation();
    }
    resetValidation(name?: string | string[]): void {
        (this.$refs.form as Form).resetValidation(name);
    }
}
</script>

<style lang="scss" scoped></style>
