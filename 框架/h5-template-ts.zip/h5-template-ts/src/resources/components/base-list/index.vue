<template>
    <van-pull-refresh v-model="refreshLoading" success-text="刷新成功" :disabled="!pull" @refresh="listMore('refresh')">
        <template v-if="isEmpty">
            <!-- 空数据插槽 -->
            <slot v-if="$scopedSlots.empty" name="empty"></slot>
            <div v-else class="empty-wrapper">
                <base-empty :type="emptyType" :image="emptyImage" :desc="emptyDesc"></base-empty>
            </div>
        </template>
        <template v-else>
            <van-list
                v-model="loading"
                :finished="finished"
                :finished-text="finishedText"
                :error.sync="error"
                error-text="请求失败，点击重新加载"
                @load="listMore('')"
            >
                <!-- slot默认插槽，由外部进行循环逻辑和数据组装，组件会传递每次请求数据到外部 -->
                <slot></slot>
                <!-- slot为item的情况，由外部传入样式，内部控制循环逻辑，建议和default的slot二选一传递 -->
                <div :style="customStyle" class="base-list">
                    <div v-for="(item, index) in privateList" :key="index" class="base-list-item">
                        <slot name="item" :row="item" :index="index"> </slot>
                    </div>
                </div>
            </van-list>
        </template>
    </van-pull-refresh>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from "vue-property-decorator";
import { PullRefresh, List } from "vant";
import BaseEmpty from "../base-empty/index.vue";
@Component({
    name: "BaseList",
    components: {
        [PullRefresh.name]: PullRefresh,
        [List.name]: List,
        BaseEmpty
    }
})
export default class BaseList extends Vue {
    //是否允许下拉
    @Prop({
        type: Boolean,
        default: true
    })
    pull?: boolean;

    //自定义wrapper样式
    @Prop({
        type: Object
    })
    customStyle?: any;

    //构造请求
    @Prop({
        required: true
    })
    req!: {
        // eslint-disable-next-line no-unused-vars
        fn: (params?: Record<string, any>) => Promise<any>;
        params?: Record<string, any>;
    };

    //数据存在的key，比如返回数据是{code:200,data:{rows:[],total:100},msg:'xxx'}，则传递rows，如果还在rows下面层级，则传递rows.xxx.xx.xx，依此递归
    @Prop({
        type: String
    })
    rowKey?: string;

    //焦点key，防止多个列表共存的情况下，重复加载（传入active的时候，必须同时传入key）
    @Prop({
        type: [String, Number]
    })
    active?: string | number;

    /** 双向绑定,list数据 */
    @Prop({
        default: () => {
            return [];
        }
    })
    list?: any;

    /** mock数据 */
    @Prop()
    mockData?: any;

    /** 空状态页类型 */
    @Prop({
        default: "order"
    })
    emptyType?: string;

    /** 空状态页image，支持vant默认 */
    @Prop()
    emptyImage?: string;

    /** 空状态描述 */
    @Prop()
    emptyDesc?: string;

    /** 加载完成提示文案 */
    @Prop({
        default: "没有更多数据了"
    })
    finishedText?: string;

    /** 分页数量 */
    @Prop({
        default: 10
    })
    size?: number;

    //当前页
    page = 1;
    //是否结束
    finished = false;
    //列表加载状态
    loading = false;
    //下拉加载提示
    refreshLoading = false;
    //是否加载失败
    error = false;
    //内部list
    privateList: any[] = [];

    //是否显示空数据状态
    get isEmpty(): boolean {
        return this.page > 1 && this.privateList.length === 0 && this.loading === false && this.error === false;
    }

    /** 监听传参，触发重新加载 */
    @Watch("req", { deep: true })
    reqChange(): void {
        this.privateList = [];
        this.$emit("update:list", []);
        this.sleep(10).then(() => {
            this.$nextTick(() => {
                this.listMore("init");
            });
        });
    }

    /** 如果做了双向绑定，则更新双向绑定的数据到实际list中 */
    @Watch("list")
    onChangeList(e: any[]): void {
        this.privateList = e;
    }
    /** 添加睡眠时间 */
    sleep(delay: number): Promise<boolean> {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve(true);
            }, delay);
        });
    }
    //加载逻辑判断
    async listMore(type: "init" | "refresh" | ""): Promise<void> {
        if (this.mockData) {
            this.loading = false;
            this.$emit("update:list", this.mockData);
            this.$emit("export", this.mockData);
            return;
        }
        if (this.$vnode.key !== undefined && this.active !== undefined && this.$vnode.key !== this.active) {
            //如果同时传入了key和active，则进行匹配校验，非活动状态的base-list组件，拒绝请求
            console.warn(
                `base-list组件当前未激活，请注意传入的key：${String(this.$vnode.key)}和active：${this.active}`
            );
            return;
        }
        if (type === "init" || type === "refresh") {
            this.page = 1;
            if (type === "init") {
                this.finished = false;
            }
            //下拉刷新时，设置list组件加载状态为true，防止触发list的onload方法
            this.loading = true;
        }
        try {
            this.error = false;
            const res = await this.req.fn({ ...this.req.params, page: this.page, size: this.size });
            this.page = this.page + 1;
            if (type === "init" || type === "refresh") {
                if (type === "init") {
                    this.privateList = [];
                    this.$emit("update:list", []);
                }
                await this.sleep(10);
            }
            // 传递每次请求的数据到外部,用于数据二次封装和外部循环逻辑
            this.$emit("export", res);
            let _list = res;
            if (this.rowKey) {
                const rowKeyArr = this.rowKey.split(".");
                rowKeyArr.forEach((item) => {
                    _list = _list[item];
                });
            }
            let _tmp = [...this.privateList, ..._list];
            if (type === "refresh") {
                _tmp = [..._list];
            }
            this.privateList = _tmp;
            this.$emit("update:list", _tmp);
            this.loading = false;
            this.refreshLoading = false;
            if (_list.length < (this.size || 10)) {
                this.finished = true;
            } else {
                this.finished = false;
            }
        } catch (e) {
            console.log(`获取列表数据失败:\n`, e, `\n`, this.req.params);
            const str = String(e);
            if (str.indexOf("当前请求已取消") !== -1 || str.indexOf("请求过快，已拦截") !== -1) {
                return;
            }
            this.refreshLoading = false;
            this.finished = false;
            this.loading = false;
            this.error = true;
        }
    }
}
</script>

<style lang="scss" scoped>
.base-list {
    height: 100%;
}
.empty-wrapper {
    height: 50vh;
    .van-empty {
        top: auto;
    }
}
</style>
