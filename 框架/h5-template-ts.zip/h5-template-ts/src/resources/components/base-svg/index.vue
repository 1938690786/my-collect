<template>
    <svg :class="svgClass" aria-hidden="true" :style="svgStyle">
        <use :xlink:href="iconName"></use>
    </svg>
</template>

<script lang="ts">
import getRealPx from "@/utils/tools/get-realpx";
import { Vue, Component, Prop } from "vue-property-decorator";

@Component({
    name: "BaseSvg"
})
export default class BaseSvg extends Vue {
    /** 名称 */
    @Prop({
        type: [String]
    })
    name?: string;

    /** class名称 */
    @Prop({
        type: [String]
    })
    className?: string;

    /** 宽度 */
    @Prop({
        type: [Number]
    })
    width?: number;

    /** 高度 */
    @Prop({
        type: [Number]
    })
    height?: number;

    /** 颜色 */
    @Prop({
        type: [String]
    })
    color?: string;

    /** 拼接svg名称 */
    get iconName(): string {
        return `#svg-${this.name}`;
    }

    get svgStyle(): any {
        return {
            width: this.width ? getRealPx(this.width) : "inherit",
            height: this.height ? getRealPx(this.height) : "inherit",
            color: this.color || "inherit"
        };
    }

    get svgClass(): string {
        if (this.className) {
            return "svg-icon " + this.className;
        } else {
            return "svg-icon";
        }
    }
}
</script>

<style lang="scss" scoped>
.svg-icon {
    vertical-align: -0.15em;
    fill: currentColor;
    overflow: hidden;
}
</style>
