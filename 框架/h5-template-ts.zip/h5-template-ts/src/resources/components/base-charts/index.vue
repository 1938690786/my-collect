<template>
    <div
        ref="base-charts"
        class="base-charts"
        :style="{
            width: $width,
            height: $height
        }"
    ></div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from "vue-property-decorator";
import getRealPx from "@/utils/tools/get-realpx/index";
import echarts from "@/config/echarts/index";
@Component({
    name: "BaseChartsLayout"
})
export default class BaseChartsLayout extends Vue {
    /** 图例宽度 */
    @Prop({
        type: [String, Number]
    })
    width?: string | number;

    /** 图例高度 */
    @Prop({
        type: [String, Number]
    })
    height?: string | number;

    /** 图例配置项*/
    @Prop({
        type: Object
    })
    ChartsOption!: any;

    /**
     * 图表类型
     * 可选值：【map】
     */
    @Prop({
        type: String
    })
    ChartsType?: string;

    charts: null | any = null;

    /**  图例宽度 */
    get $width(): string {
        return this.width ? getRealPx(+this.width) + "px" : "100%";
    }

    /** 图例高度 */
    get $height(): string {
        return getRealPx(this.height ? +this.height : 300) + "px";
    }

    @Watch("ChartsOption", { immediate: true })
    onChartsOptionChanged(): void {
        this.$nextTick(() => {
            this.init_charts();
        });
    }

    init_charts(): void {
        /**
         * 根据 ChartsType 判断是当前图表类型是否是地图(map)
         * 注意：该动作必须放在 init 之前执行
         */
        if (this.ChartsType === "map") {
            //导入地图的json数据
            const chinaJSON = require("@/config/echarts/map/chinaChange.json");
            //初始化地图
            echarts.registerMap("china", chinaJSON);
        }

        // 基于准备好的dom，初始化echarts实例
        const ECHARTS_H = this.$refs["base-charts"] as HTMLElement;
        this.charts = echarts.init(ECHARTS_H);
        this.charts.setOption(this.ChartsOption);
    }
}
</script>

<style scoped lang="scss"></style>
