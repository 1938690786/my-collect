<template>
    <div class="base-loading">
        <div v-show="loading" class="loading">
            <div v-if="src" class="custom-wrapper">
                <img class="custom-loading-iamge" mode="widthFix" :src="src" />
                <div class="custom-loading-text">{{ loadingText }}</div>
            </div>
            <div v-else class="spin">
                <div class="inner" :style="innerStyle"></div>
            </div>
        </div>
        <div v-show="error" class="loading">
            <van-empty image="error" :description="message || '加载失败，点击重试'">
                <van-button round type="danger" class="error-button" @click="handleRetry">重试</van-button>
            </van-empty>
        </div>
        <slot v-if="!loading && !error"></slot>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { Empty, Button } from "vant";
@Component({
    name: "BaseLoading",
    components: {
        [Empty.name]: Empty,
        [Button.name]: Button
    }
})
export default class BaseLoading extends Vue {
    /**加载状态*/
    @Prop({
        default: true
    })
    loading!: boolean;

    /**自定义图片地址*/
    @Prop({})
    src?: string;

    /**loading颜色*/
    @Prop({
        default: "#409eff"
    })
    color?: string;

    /**loading文字*/
    @Prop({})
    text?: string;

    /**加载错误*/
    @Prop({
        default: false
    })
    error?: boolean;

    /** 错误描述 */
    @Prop()
    message?: string;

    /**边框颜色*/
    get innerStyle(): any {
        return {
            borderColor: `${this.color} transparent;`
        };
    }

    /** 重试 */
    handleRetry(): void {
        this.$emit("retry");
    }
}
</script>

<style lang="scss" scoped>
$themeColor: #409eff;
$bgColor: #fff;
.loading {
    z-index: 9999;
    background-color: $bgColor;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;

    .custom-loading-image {
        width: 200px;
        display: block;
    }

    .custom-loading-text {
        color: #999999;
        font-size: 28px;
    }

    .spin {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 64px;
        height: 64px;
    }
    .inner {
        width: 46px;
        height: 46px;
        margin: 1px;
        border-radius: 50%;
        border: 5px solid transparent;
        border-color: $themeColor transparent;
        animation: spin 1.2s linear infinite;
    }
    @keyframes spin {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }
    .error-button {
        width: 320px;
        height: 80px;
    }
}
</style>
