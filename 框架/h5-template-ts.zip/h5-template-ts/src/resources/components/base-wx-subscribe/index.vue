<template>
    <wx-open-subscribe :style="style" :template="template">
        <script type="text/wxtag-template">
            <style>
              .subscribe-btn {
                width:1000px;
                height:1000px;
                background:#000
              }
            </style>
            <div class="subscribe-btn"></div>
        </script>
    </wx-open-subscribe>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
@Component({
    name: "BaseWxSubscribe",
    components: {}
})
export default class BaseWxSubscribe extends Vue {
    /** 模板ID */
    @Prop({
        default: "",
        required: true
    })
    template!: string;

    /** 层级 */
    @Prop({
        default: 2
    })
    zIndex?: number;

    get style(): any {
        return {
            "z-index": this.zIndex || 2,
            position: "absolute",
            top: 0,
            left: 0,
            opacity: process.env.VUE_APP_MODE === "development" ? 0.8 : 0
        };
    }
}
</script>

<style lang="scss" scoped></style>
