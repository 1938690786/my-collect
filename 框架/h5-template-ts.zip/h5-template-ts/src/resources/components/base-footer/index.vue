<template>
    <div class="base-footer" :style="footerStyle">
        <slot name="default-footer"></slot>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
interface IProp {
    [key: string]: any;
}

@Component({
    name: "BaseFooter"
})
export default class BaseFooter extends Vue {
    @Prop({
        type: [Object]
    })
    footerStyle?: IProp;
}
</script>

<style lang="scss" scoped>
.base-footer {
    position: fixed;
    bottom: 0;
    left: 0;
    background-color: #fff;
    width: 100vw;
    height: 100px;
    padding: 22px 20px;
    font-size: 26px;
}
</style>
