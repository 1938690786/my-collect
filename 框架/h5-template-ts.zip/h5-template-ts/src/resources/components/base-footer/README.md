### 组件名称：footer 组件

### 场景 : 页面底部固定定位的操作区域

### Prop

footer-style 可以覆盖组件默认样式

### 用法

```html
<BaseFooter :footer-style="test6">
    <template #default-footer>
        <div>一个很6的组件</div>
    </template>
</BaseFooter>

test6 = { color: "red" };
```
