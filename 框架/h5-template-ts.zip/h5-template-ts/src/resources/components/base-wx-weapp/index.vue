<template>
    <wx-open-launch-weapp :username="appid" :path="path" :style="style">
        <script type="text/wxtag-template">
            <style>
                .launch-btn {
                    width:1000px;
                    height:1000px;
                    background:#000
              }
            </style>
            <div class="launch-btn"></div>
        </script>
    </wx-open-launch-weapp>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
@Component({
    name: "BaseWxWeapp",
    components: {}
})
export default class BaseWxWeapp extends Vue {
    /** 小程序跳转路径，例：pages/home/index */
    @Prop({
        default: "",
        required: true
    })
    path!: string;

    /** 小程序AppID */
    @Prop({
        default: "",
        required: true
    })
    appid!: string;

    /** 层级 */
    @Prop({
        default: 2
    })
    zIndex?: number;

    get style(): any {
        return {
            "z-index": this.zIndex || 2,
            position: "absolute",
            top: 0,
            left: 0,
            opacity: process.env.VUE_APP_MODE === "development" ? 0.8 : 0
        };
    }
}
</script>

<style lang="scss" scoped></style>
