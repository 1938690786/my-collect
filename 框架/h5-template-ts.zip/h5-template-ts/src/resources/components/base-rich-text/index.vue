<template>
    <div v-dompurify-html="content"></div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import VueDOMPurifyHTML from "vue-dompurify-html";

Vue.use(VueDOMPurifyHTML);
@Component({
    name: "BaseRichText"
})
export default class BaseRichText extends Vue {
    @Prop({
        default: ""
    })
    content?: string;
}
</script>

<style lang="scss" scoped></style>
