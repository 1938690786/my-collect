<template>
    <van-tabs
        v-model="bindValue"
        class="base-tabs-van-tabs"
        v-bind="$attrs"
        :title-inactive-color="inActiveColor"
        :title-active-color="activeColor"
        :animated="true"
        :sticky="sticky"
        :background="background"
        @click="TabsClick"
        @change="TabsChange"
    >
        <van-tab v-for="(item, index) in list" :key="index" :title="titleKey ? item[titleKey] : item.label">
            <slot :row="index" />
        </van-tab>
    </van-tabs>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from "vue-property-decorator";
import { Tabs, Tab } from "vant";
import { BaseTab } from "/#/base";

@Component({
    name: "BaseTabs",
    components: {
        [Tabs.name]: Tabs,
        [Tab.name]: Tab
    }
})
export default class BaseTabs extends Vue {
    /** tabs列表数据 */
    @Prop({
        type: Array,
        default: []
    })
    readonly list!: BaseTab[];

    /** 标题所在key */
    @Prop({
        type: String,
        default: ""
    })
    titleKey?: string;

    /**绑定的标签*/
    @Prop({
        type: Number,
        default: 0
    })
    value!: number;

    /** 实现value双向绑定 */
    // get bindValue(): string | number {
    //     return this.value;
    // }
    // set bindValue(newVal: string | number) {
    //     console.log("newVal", newVal);
    //     this.$emit("input", newVal);
    // }
    bindValue = Number(this.value);

    @Prop({
        type: Boolean,
        default: true
    })
    sticky?: boolean;

    /** 标签栏背景色 */
    @Prop({
        type: String,
        default: "#ffffff"
    })
    background?: string;

    /**选中标签文字颜色*/
    @Prop({
        type: String,
        default: "#3B3B3B"
    })
    inActiveColor?: string;

    /**默认标签文字颜色*/
    @Prop({
        type: String,
        default: "#F12F1A"
    })
    activeColor?: string;

    @Watch("value")
    onWatchValue(val: number): void {
        this.bindValue = val;
    }
    /**
     * 点击标签时触发
     * @param index：索引
     * @param  value：索引值
     */
    TabsClick(index: number | string, value: string): void {
        this.$emit("give-tabs-click", index, value);
    }

    /**
     * 当前激活的标签改变时触发
     * @param index：索引
     * @param  value：索引值
     */
    TabsChange(index: number | string, value: string): void {
        this.$emit("change", index, value);
    }
}
</script>

<style lang="scss" scoped>
.base-tabs-van-tabs {
    margin-bottom: 20px;
    // ::v-deep .van-tabs__nav {
    //     background: none;
    // }
    ::v-deep .van-tabs__line {
        height: 4px;
        background-color: #f12f1a;
        // background-size: 100% 100%;
        // background-repeat: no-repeat;
        // background-image: url("~@/assets/images/base/tabs-active.png");
    }
    ::v-deep .van-tab--active {
        font-weight: bold;
    }
}
</style>
