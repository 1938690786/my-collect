<template>
    <van-empty
        class="base-empty"
        :class="[image ? '' : type]"
        :image="image || iconMap[type].icon"
        :description="desc || iconMap[type].message"
    ></van-empty>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { Empty } from "vant";
@Component({
    name: "BaseEmpty",
    components: {
        [Empty.name]: Empty
    }
})
export default class BaseEmpty extends Vue {
    /** 空类型 */
    @Prop({
        default: "result"
    })
    type?: string;

    /** 自定义描述 */
    @Prop()
    desc?: string;

    /** 自定义图片 */
    @Prop()
    image?: string;

    /** 数据结构 */
    iconMap = {
        result: {
            icon: require("@/assets/images/empty/result@2x.png"),
            message: "搜索无结果"
        },
        address: {
            icon: require("@/assets/images/empty/address@2x.png"),
            message: "暂无地址"
        },
        card: {
            icon: require("@/assets/images/empty/card@2x.png"),
            message: "无商品"
        },
        coupons: {
            icon: require("@/assets/images/empty/coupons@2x.png"),
            message: "无优惠券"
        },
        data: {
            icon: require("@/assets/images/empty/data@2x.png"),
            message: "暂无数据"
        },
        error: {
            icon: require("@/assets/images/empty/error@2x.png"),
            message: "页面发生错误"
        },
        live: {
            icon: require("@/assets/images/empty/live@2x.png"),
            message: "暂无直播"
        },
        message: {
            icon: require("@/assets/images/empty/message@2x.png"),
            message: "暂无消息"
        },
        money: {
            icon: require("@/assets/images/empty/money@2x.png"),
            message: "暂无余额明细"
        },
        network: {
            icon: require("@/assets/images/empty/network@2x.png"),
            message: "网络错误"
        },
        open: {
            icon: require("@/assets/images/empty/open@2x.png"),
            message: "暂未开业"
        },
        order: {
            icon: require("@/assets/images/empty/order@2x.png"),
            message: "您还没有相关订单"
        },
        uphold: {
            icon: require("@/assets/images/empty/uphold@2x.png"),
            message: "功能未开放"
        },
        goods: {
            icon: require("@/assets/images/empty/goods@2x.png"),
            message: "未搜索到相关商品,换个关键词再试试"
        }
    };
}
</script>

<style lang="scss" scoped>
.base-empty {
    margin-top: 10vh;
    ::v-deep.van-empty__description {
        margin-top: 40px;
    }
}
.result {
    ::v-deep.van-empty__image {
        width: 361px;
        height: 177px;
    }
}
.address {
    ::v-deep.van-empty__image {
        width: 337px;
        height: 177px;
    }
}
.card {
    ::v-deep.van-empty__image {
        width: 370px;
        height: 174px;
    }
}
.coupons {
    ::v-deep.van-empty__image {
        width: 343px;
        height: 168px;
    }
}
.data {
    ::v-deep.van-empty__image {
        width: 361px;
        height: 198px;
    }
}
.error {
    ::v-deep.van-empty__image {
        width: 364px;
        height: 203px;
    }
}
.live {
    ::v-deep.van-empty__image {
        width: 339px;
        height: 172px;
    }
}
.message {
    ::v-deep.van-empty__image {
        width: 362px;
        height: 181px;
    }
}
.money {
    ::v-deep.van-empty__image {
        width: 361px;
        height: 175px;
    }
}
.network {
    ::v-deep.van-empty__image {
        width: 345px;
        height: 167px;
    }
}
.open {
    ::v-deep.van-empty__image {
        width: 364px;
        height: 174px;
    }
}
.order {
    ::v-deep.van-empty__image {
        width: 339px;
        height: 173px;
    }
}
.uphold {
    ::v-deep.van-empty__image {
        width: 343px;
        height: 157px;
    }
}
</style>
