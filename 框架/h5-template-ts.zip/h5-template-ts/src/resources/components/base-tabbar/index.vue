<template>
    <van-tabbar route active-color="#F12F1A" inactive-color="#000">
        <template v-for="(item, index) in tabs">
            <van-tabbar-item :key="index" :badge="item.badge" replace :to="item.router">
                <div style="display: none">{{ getCardNumber }}</div>
                <span>{{ item.title }}</span
                ><template #icon="props"><img :src="props.active ? item.active : item.inactive" /></template
            ></van-tabbar-item>
        </template>
    </van-tabbar>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
import { Tabbar, TabbarItem } from "vant";
import tabbar from "@/config/tabbar";
@Component({
    name: "BaseTabbar",
    components: {
        [Tabbar.name]: Tabbar,
        [TabbarItem.name]: TabbarItem
    }
})
export default class BaseTabbar extends Vue {
    get tabs(): any {
        return tabbar;
    }
    get getCardNumber(): string {
        this.tabs[3].badge = this.$store.state.card.count == "0" ? "" : this.$store.state.card.count;
        // console.log("this.$store.state.card.count", this.$store.state.card.count);
        return this.$store.state.card.count;
    }
}
</script>

<style lang="scss" scoped></style>
