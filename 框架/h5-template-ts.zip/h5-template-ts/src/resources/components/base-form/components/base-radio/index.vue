<template>
    <van-field class="base-radio" :placeholder="placeholder" v-bind="$attrs" v-on="$listeners">
        <template #label>
            <slot name="label" />
        </template>
        <template #input>
            <slot name="input">
                <van-radio-group v-model="model" direction="horizontal">
                    <van-radio v-for="item in options" :key="item.value" :name="item.value">{{ item.label }}</van-radio>
                </van-radio-group>
            </slot>
        </template>
        <template #left-icon>
            <slot name="left-icon" />
        </template>
        <template #right-icon>
            <slot name="right-icon" />
        </template>
        <template #button>
            <slot name="button" />
        </template>
        <template #extra>
            <slot name="extra" />
        </template>
    </van-field>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { Field, RadioGroup, Radio } from "vant";

@Component({
    components: {
        [Field.name]: Field,
        [RadioGroup.name]: RadioGroup,
        [Radio.name]: Radio
    }
})
export default class BaseRadio extends Vue {
    @Prop({
        default: ""
    })
    value!: number | string;

    @Prop({
        default: "请输入"
    })
    placeholder?: string;

    @Prop({
        default: () => {
            return [];
        }
    })
    options?: any;

    get model(): number | string {
        return this.value;
    }
    set model(newVal: number | string) {
        this.$emit("input", newVal);
    }
}
</script>

<style lang="scss" scoped>
.base-radio::after {
    border-color: #ededed;
}
</style>
