<template>
    <van-field v-model.trim="model" class="base-input" :placeholder="placeholder" v-bind="$attrs" v-on="$listeners">
        <template #label>
            <slot name="label" />
        </template>
        <template #input>
            <slot name="input" />
        </template>
        <template #left-icon>
            <slot name="left-icon" />
        </template>
        <template #right-icon>
            <slot name="right-icon" />
        </template>
        <template #button>
            <slot name="button" />
        </template>
        <template #extra>
            <slot name="extra" />
        </template>
    </van-field>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { Field } from "vant";

@Component({
    name: "BaseInput",
    components: {
        [Field.name]: Field
    }
})
export default class BaseInput extends Vue {
    @Prop({
        default: ""
    })
    value!: string | number;
    @Prop({
        default: "请输入"
    })
    placeholder?: string;

    get model(): string | number {
        return this.value;
    }
    set model(newVal: string | number) {
        this.$emit("input", newVal);
    }
}
</script>

<style lang="scss" scoped>
.base-input::after {
    border-color: #ededed;
}
</style>
