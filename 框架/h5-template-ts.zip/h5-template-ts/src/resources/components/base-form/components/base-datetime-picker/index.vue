<template>
    <van-cell class="base-datetime_wrapper">
        <van-field
            :value="showName"
            class="base-datetime"
            :placeholder="placeholder"
            v-bind="$attrs"
            readonly
            v-on="$listeners"
            @click="visible = true"
        >
            <template #label>
                <slot name="label" />
            </template>
            <template #input>
                <slot name="input" />
            </template>
            <template #left-icon>
                <slot name="left-icon" />
            </template>
            <template #right-icon>
                <slot name="right-icon" />
            </template>
            <template #button>
                <slot name="button" />
            </template>
            <template #extra>
                <slot name="extra" />
            </template>
        </van-field>
        <van-popup v-model="visible" position="bottom">
            <template v-if="options.type === 'time'">
                <van-datetime-picker
                    :value="datetimevalue2"
                    v-bind="options"
                    @confirm="onConfirm"
                    @cancel="visible = false"
                />
            </template>
            <template v-else>
                <van-datetime-picker
                    :value="datetimevalue"
                    v-bind="options"
                    @confirm="onConfirm"
                    @cancel="visible = false"
                />
            </template>
        </van-popup>
    </van-cell>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { formatDate } from "@/utils/operation/index";
import { Cell, Field, Popup, DatetimePicker } from "vant";
@Component({
    name: "BaseDatetime",
    components: {
        [Cell.name]: Cell,
        [Field.name]: Field,
        [Popup.name]: Popup,
        [DatetimePicker.name]: DatetimePicker
    }
})
export default class BaseDatetime extends Vue {
    @Prop({
        default: ""
    })
    value!: string;

    @Prop({
        default: "请选择"
    })
    placeholder?: string;

    @Prop({
        default: () => {
            return {
                type: "date"
            };
        }
    })
    options?: any;

    visible = false;

    datetimevalue = new Date();
    datetimevalue2 = "";

    get showName(): any {
        if (this.options.type === "time") {
            this.datetimevalue2 = this.value || "";
        } else {
            this.datetimevalue = this.value ? new Date(this.value.replace(/-/g, "/")) : new Date();
        }
        return this.value;
    }
    set showName(newVal: any) {
        this.$emit("input", newVal);
    }

    onConfirm(val: any): void {
        this.visible = false;
        if (this.options.type === "time") {
            //时分
            this.showName = val;
        } else if (this.options.type === "month-day") {
            //月日
            this.showName = formatDate(val, "MM-DD");
        } else if (this.options.type === "year-month") {
            //年月
            this.showName = formatDate(val, "YYYY-MM");
        } else if (this.options.type === "date") {
            //年月日
            this.showName = formatDate(val, "YYYY-MM-DD");
        } else if (this.options.type === "datehour") {
            //年月日时
            this.showName = formatDate(val, "YYYY-MM-DD HH:mm");
        } else if (this.options.type === "datetime") {
            //年月日时分
            this.showName = formatDate(val, "YYYY-MM-DD HH:mm");
        }
    }
}
</script>

<style lang="scss" scoped>
.base-datetime_wrapper {
    padding: 0;
    &::after {
        border-color: #ededed;
    }
}
</style>
