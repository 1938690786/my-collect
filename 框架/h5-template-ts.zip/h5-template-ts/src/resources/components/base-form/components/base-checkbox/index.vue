<template>
    <van-field class="base-checkbox" :placeholder="placeholder" v-bind="$attrs" v-on="$listeners">
        <template #label>
            <slot name="label" />
        </template>
        <template #input>
            <slot name="input">
                <van-checkbox-group v-model="model" direction="horizontal">
                    <van-checkbox v-for="item in options" :key="item.value" :name="item.value" shape="square">
                        {{ item.label }}
                    </van-checkbox>
                </van-checkbox-group>
            </slot>
        </template>
        <template #left-icon>
            <slot name="left-icon" />
        </template>
        <template #right-icon>
            <slot name="right-icon" />
        </template>
        <template #button>
            <slot name="button" />
        </template>
        <template #extra>
            <slot name="extra" />
        </template>
    </van-field>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { Field, Checkbox, CheckboxGroup } from "vant";
@Component({
    name: "BaseCheckbox",
    components: {
        [Field.name]: Field,
        [Checkbox.name]: Checkbox,
        [CheckboxGroup.name]: CheckboxGroup
    }
})
export default class BaseCheckbox extends Vue {
    @Prop({
        default: () => {
            return [];
        }
    })
    value!: any[];

    @Prop({
        default: "请输入"
    })
    placeholder?: string;

    @Prop({
        default: () => {
            return [];
        }
    })
    options?: any;

    get model(): any[] {
        return this.value;
    }
    set model(newVal: any[]) {
        this.$emit("input", newVal);
    }
}
</script>

<style lang="scss" scoped>
.base-checkbox::after {
    border-color: #ededed;
}
</style>
