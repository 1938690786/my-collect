<template>
    <van-field class="base-uploader" v-bind="$attrs" v-on="$listeners">
        <template #label>
            <slot name="label" />
        </template>
        <template #input>
            <slot name="input">
                <van-uploader
                    ref="uploaderControl"
                    v-model="fileList"
                    v-bind="options"
                    multiple
                    :max-size="10 * 1024 * 1024"
                    :after-read="afterRead"
                    :max-count="maxCount"
                    :upload-text="uploadText"
                    :upload-icon="uploadIcon"
                    @oversize="onOversize"
                    @delete="delUpload"
                    v-on="$listeners"
                >
                    <slot name="uploader"></slot>
                </van-uploader>
            </slot>
        </template>
        <template #left-icon>
            <slot name="left-icon" />
        </template>
        <template #right-icon>
            <slot name="right-icon" />
        </template>
        <template #button>
            <slot name="button" />
        </template>
        <template #extra>
            <slot name="extra" />
        </template>
    </van-field>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from "vue-property-decorator";
import { deepClone } from "@/utils/operation/index";
import { Field, Uploader, Toast } from "vant";
import { uploadImage } from "@/config/apis/common";
@Component({
    name: "BaseUploader",
    components: {
        [Field.name]: Field,
        [Uploader.name]: Uploader
    }
})
export default class BaseUploader extends Vue {
    @Prop({
        required: true,
        default: () => {
            return [];
        }
    })
    value!: { url: string }[];

    @Prop({
        default: () => {
            return {};
        }
    })
    options?: any;

    //上传完成时触发
    @Prop({
        type: Function
    })
    uploadEnd?: any;

    // 上传中触发
    @Prop({
        type: Function
    })
    uploading?: any;

    // 自定义文字
    @Prop({
        type: String
    })
    uploadText?: any;

    // 自定义图片
    @Prop({
        type: String
    })
    uploadIcon?: any;

    // 限制文件上传数量
    @Prop({
        type: String
    })
    maxCount?: any;

    fileList = []; // 上传图片存储
    fileMap = {} as any; //图片name对应图片url，用于删除寻找

    @Watch("value", { immediate: true })
    onWatchValue(): void {
        console.log("this.value", this.value);
        this.fileList = deepClone(this.value);
    }

    /**
     * 使用方法：通过 ref 可以获取到 BaseUploader 实例并调用实例方法toggle
     * 方法说明：主动调起文件选择
     * */
    toggle(): void {
        this.$nextTick(() => {
            (this.$refs.uploaderControl as Uploader).chooseFile();
        });
    }

    /** 文件大小超过限制时触发 */
    onOversize(): void {
        Toast("文件大小不能超过 10M");
    }

    /** 删除图片文件 */
    delUpload(file: any): void {
        const url = file.url;
        if (url) {
            const arr = this.value;
            arr.splice(
                arr.findIndex((item) => item === url),
                1
            );
            this.uploadEnd(arr, this.$attrs["data-uploadname"]); // 删除完成时触发
        }
    }

    /** 异步上传图片 */
    async afterRead(file: any): Promise<void> {
        let arr = [];
        if (Array.isArray(file)) {
            arr = file;
        } else {
            arr.push(file);
        }
        arr.forEach((item) => {
            item.message = "上传中";
            item.status = "uploading";
            if (this.uploading) {
                this.uploading(item);
            }
            uploadImage(item)
                .then((res) => {
                    console.log(res);

                    item.status = "done";
                    const tmp = this.value;
                    // this.$set(this.fileMap, item.file.name, res.url);
                    // this.$emit("input", tmp.push({ url: res.url }));
                    const { path_name }: any = res;
                    this.$set(this.fileMap, item.file.name, path_name);
                    this.$emit("input", tmp.push({ url: path_name }));
                    this.uploadEnd(tmp, this.$attrs["data-uploadname"]); //上传完成时触发
                })
                .catch(() => {
                    item.status = "failed";
                    item.message = "上传失败";
                });
        });
    }
}
</script>

<style lang="scss" scoped>
.base-uploader::after {
    border-color: #ededed;
}
</style>
