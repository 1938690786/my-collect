<template>
    <van-cell class="base-area_wrapper">
        <van-field
            :value="showName"
            class="base-area"
            :placeholder="placeholder"
            v-bind="$attrs"
            readonly
            v-on="$listeners"
            @click="handleShowPop"
        >
            <template #label>
                <slot name="label" />
            </template>
            <template #input>
                <slot name="input" />
            </template>
            <template #left-icon>
                <slot name="left-icon" />
            </template>
            <template #right-icon>
                <slot name="right-icon" />
            </template>
            <template #button>
                <slot name="button" />
            </template>
            <template #extra>
                <slot name="extra" />
            </template>
        </van-field>
        <van-popup v-model="visible" position="bottom" closeable round>
            <van-cascader
                v-model="cascaderValue"
                class="cascader"
                title="请选择所在地区"
                :field-names="fieldNames"
                :options="areaList"
                :closeable="false"
                @cancel="visible = false"
                @finish="onFinish"
            />
        </van-popup>
    </van-cell>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { Cell, Field, Popup, Cascader } from "vant";
import { getArea, _RegArea } from "@/config/apis/login";
@Component({
    name: "BaseArea",
    components: {
        [Cell.name]: Cell,
        [Field.name]: Field,
        [Popup.name]: Popup,
        [Cascader.name]: Cascader
    }
})
export default class BaseArea extends Vue {
    @Prop({
        default: []
    })
    value!: Array<any>;

    @Prop({
        default: "请选择"
    })
    placeholder?: string;

    areaList: _RegArea[] = []; //省市区列表

    fieldNames = {
        text: "label"
    };

    visible = false;
    cascaderValue = "";

    get showName(): any {
        if (this.value.includes(0)) {
            this.cascaderValue = "";
            return "";
        }
        this.cascaderValue = this.value[this.value.length - 1];
        const map = this.flatArray(this.areaList);
        const str = this.value.reduce((res, key) => {
            return res + "/" + map[key];
        }, "");
        return str.substr(1);
    }

    flatArray(arr: any[]): any {
        const result = {} as any;
        // eslint-disable-next-line no-unused-vars
        const flat = function (node: any, parentNode?: any): any {
            result[node.value] = node.label;
            if (node.children && node.children.length) {
                node.children.forEach((item: any) => {
                    flat(item, node);
                });
            }
        };
        arr.forEach((item) => {
            flat(item);
        });
        return result;
    }

    handleShowPop(): void {
        this.visible = true;
    }

    onFinish({ selectedOptions }: any): void {
        this.visible = false;
        const locationList = selectedOptions.map((cur: any) => {
            return cur.value;
        }, "");
        this.$emit("input", locationList);
    }

    async created(): Promise<void> {
        const res = await getArea();
        this.areaList = res;
    }
}
</script>

<style lang="scss" scoped>
.base-area_wrapper {
    padding: 0;
    &::after {
        border-color: #ededed;
    }
}
</style>
