<template>
    <van-cell class="base-select_wrapper">
        <van-field
            :value="showName"
            class="base-select"
            :placeholder="placeholder"
            v-bind="$attrs"
            readonly
            v-on="$listeners"
            @click="visible = true"
        >
            <template #label>
                <slot name="label" />
            </template>
            <template #input>
                <slot name="input" />
            </template>
            <template #left-icon>
                <slot name="left-icon" />
            </template>
            <template #right-icon>
                <slot name="right-icon" />
            </template>
            <template #button>
                <slot name="button" />
            </template>
            <template #extra>
                <slot name="extra" />
            </template>
        </van-field>
        <van-action-sheet v-model="visible" :actions="HandleOptions(options)" cancel-text="取消" @select="select" />
    </van-cell>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { Cell, Field, ActionSheet } from "vant";
@Component({
    name: "BaseSelect",
    components: {
        [Cell.name]: Cell,
        [Field.name]: Field,
        [ActionSheet.name]: ActionSheet
    }
})
export default class BaseSelect extends Vue {
    @Prop({
        default: ""
    })
    value!: string | number;

    @Prop({
        default: "请选择"
    })
    placeholder?: string;

    /** 可选项数据源  结构{ name: "name", value: "value" }[] */
    @Prop({
        default: () => {
            return {};
        }
    })
    options?: any;

    /** 自定义 options 结构中的字段  */
    @Prop({
        type: Object,
        default: () => {
            return { name: "name", value: "value" };
        }
    })
    fieldNames?: any;

    visible = false;

    get showName(): string | number {
        const actions = this.HandleOptions(this.options) || [];
        const obj = actions.find((item: any) => item.value === String(this.value));
        return obj ? obj.name : "";
    }
    set showName(newVal: string | number) {
        this.$emit("input", newVal);
    }

    select(val: any): void {
        this.visible = false;
        this.showName = val.value;
        const { change }: any = this.$listeners;
        change && change(val);
    }

    HandleOptions(options: { name: string; value: string | number }[]): { name: string; value: string | number }[] {
        let OPTIONS: { name: string; value: string | number }[] = [];
        options.find((item: any) => {
            OPTIONS.push({
                name: item[this.fieldNames.name],
                value: String(item[this.fieldNames.value])
            });
        });
        return OPTIONS;
    }
}
</script>

<style lang="scss" scoped>
.base-select_wrapper {
    padding: 0;
    &::after {
        border-color: #ededed;
    }
}
</style>
