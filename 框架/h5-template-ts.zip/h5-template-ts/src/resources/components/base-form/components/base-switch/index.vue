<template>
    <van-field class="base-switch" :placeholder="placeholder" v-bind="$attrs" v-on="$listeners">
        <template #label>
            <slot name="label" />
        </template>
        <template #input>
            <slot name="input">
                <van-switch v-model="model" v-bind="options" />
            </slot>
        </template>
        <template #left-icon>
            <slot name="left-icon" />
        </template>
        <template #right-icon>
            <slot name="right-icon" />
        </template>
        <template #button>
            <slot name="button" />
        </template>
        <template #extra>
            <slot name="extra" />
        </template>
    </van-field>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { Field, Switch } from "vant";

@Component({
    components: {
        [Field.name]: Field,
        [Switch.name]: Switch
    }
})
export default class BaseSwitch extends Vue {
    @Prop({
        default: false
    })
    value!: any;

    @Prop({
        default: "请输入"
    })
    placeholder?: string;

    @Prop({
        default: () => {
            return {
                size: "20px"
            };
        }
    })
    options?: any;

    get model(): any {
        return this.value;
    }
    set model(newVal: any) {
        this.$emit("input", newVal);
    }
}
</script>

<style lang="scss" scoped>
.base-switch::after {
    border-color: #ededed;
}
.van-switch--on {
    background-color: #f12f1a;
}
</style>
