<template>
    <van-form ref="form" class="base-form" v-bind="form">
        <slot name="avatar" />
        <template v-for="(item, index) in formItems">
            <van-cell-group :key="index" :border="false">
                <template v-for="group in item.groups">
                    <base-input
                        v-if="!group.inputType || group.inputType === 'input'"
                        :key="group.name"
                        v-model.trim="model[group.name]"
                        v-bind="group"
                    ></base-input>
                    <base-input
                        v-if="group.inputType === 'textarea'"
                        :key="group.name"
                        v-model.trim="model[group.name]"
                        type="textarea"
                        v-bind="group"
                    ></base-input>
                    <base-select
                        v-if="group.inputType === 'select'"
                        :key="group.name"
                        v-model="model[group.name]"
                        v-bind="group"
                    >
                    </base-select>
                    <base-datetime
                        v-if="group.inputType === 'datetime'"
                        :key="group.name"
                        v-model="model[group.name]"
                        v-bind="group"
                    ></base-datetime>
                    <base-area
                        v-if="group.inputType === 'area'"
                        :key="group.name"
                        v-model="model[group.name]"
                        v-bind="group"
                    ></base-area>
                    <base-uploader
                        v-if="group.inputType === 'uploader'"
                        :key="group.name"
                        v-model="model[group.name]"
                        v-bind="group"
                    >
                        <!-- 通过默认插槽可以自定义上传区域的样式。 -->
                        <template #uploader>
                            <slot name="uploader"></slot>
                        </template>
                    </base-uploader>
                    <base-checkbox
                        v-if="group.inputType === 'checkbox'"
                        :key="group.name"
                        v-model="model[group.name]"
                        v-bind="group"
                    ></base-checkbox>
                    <base-radio
                        v-if="group.inputType === 'radio'"
                        :key="group.name"
                        v-model="model[group.name]"
                        v-bind="group"
                    ></base-radio>
                    <base-switch
                        v-if="group.inputType === 'switch'"
                        :key="group.name"
                        v-model="model[group.name]"
                        v-bind="group"
                    ></base-switch>
                    <template v-if="group.inputType === 'slot'">
                        <slot :name="group.name" :form-item="group" :model="model"></slot>
                    </template>
                </template>
            </van-cell-group>
        </template>
    </van-form>
</template>

<script lang="ts">
import { Vue, Component, Prop, PropSync } from "vue-property-decorator";
import { Form, CellGroup } from "vant";
import BaseInput from "./components/base-input/index.vue";
import BaseSelect from "./components/base-select/index.vue";
import BaseDatetime from "./components/base-datetime-picker/index.vue";
import BaseArea from "./components/base-area-picker/index.vue";
import BaseUploader from "./components/base-uploader/index.vue";
import BaseCheckbox from "./components/base-checkbox/index.vue";
import BaseRadio from "./components/base-radio/index.vue";
import BaseSwitch from "./components/base-switch/index.vue";
@Component({
    name: "BaseForm",
    components: {
        [Form.name]: Form,
        [CellGroup.name]: CellGroup,
        BaseInput,
        BaseSelect,
        BaseDatetime,
        BaseArea,
        BaseUploader,
        BaseCheckbox,
        BaseRadio,
        BaseSwitch
    }
})
export default class BaseForm extends Vue {
    @Prop({
        type: Object,
        required: true,
        default: () => {
            return {};
        }
    })
    data!: any;
    // form配置
    @Prop({
        default: () => {
            return {
                labelAlign: "left", //表单项 label 对齐方式，可选值为 left center right
                inputAlign: "right", //输入框对齐方式，可选值为left center right
                errorMessageAlign: "right" //错误提示文案对齐方式，可选值为left center right
            };
        }
    })
    form?: any;
    // form-item配置
    @Prop({
        type: Array,
        default: () => {
            return [];
        }
    })
    formItems?: any[];

    @PropSync("data")
    model!: any;

    validate(name?: string | string[]): any {
        return (this.$refs.form as Form).validate(name);
        // .then(() => {
        //     this.$emit("on-form", {
        //         event: "submit"
        //     });
        // })
        // .catch(() => ({}));
    }
    resetValidation(name?: string | string[]): void {
        (this.$refs.form as Form).resetValidation(name);
    }
    submit(): void {
        this.validate();
    }
    created(): void {
        console.log("model", this.model);
    }
}
</script>

<style lang="scss" scoped>
.base-form {
    ::v-deep .van-cell-group:not(:last-child) {
        margin-bottom: 20px;
    }
    ::v-deep .van-field__label {
        color: #000;
        font-size: 28px;
    }
    ::v-deep .van-field__control {
        color: #666;
    }
}
</style>
