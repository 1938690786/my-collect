<template>
    <div class="base-format-money" :style="customStyle">
        <span class="money-symbol">¥</span>
        <span class="money-inter" :style="interStyle">{{ inter }}</span>
        <span class="money-decimal">.{{ decimal }}</span>
        <span v-if="line" class="line" :style="lineStyle">¥ {{ line }}</span>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from "vue-property-decorator";
import float from "@/utils/tools/float/index";
import getRealPx from "@/utils/tools/get-realpx/index";
@Component({
    name: "BaseFormatMoney",
    components: {}
})
export default class BaseFormatMoney extends Vue {
    /**金额*/
    @Prop()
    money!: [number, string];

    /**基础字体大小,一般适用符号,小数点,小数位*/
    @Prop({
        default: 24
    })
    baseSize?: number;

    /**整数字体大小*/
    @Prop({
        default: 32
    })
    interSize?: number;

    /** 划线价 */
    @Prop()
    line?: [string, number];

    @Prop({
        default: 20
    })
    lineSIze?: number;

    /** 颜色 */
    @Prop({
        default: "#fb2010"
    })
    color?: string;

    /**整数*/
    inter = "0";
    /**小数*/
    decimal = "00";

    @Watch("money", { immediate: true })
    onWatchVisible(): void {
        const num = Number(this.money);
        if (isNaN(num)) {
            console.error("格式化金额出错,金额是NaN:", this.money);
            return;
        }
        const str = float.fix(num, 2);
        const strArr = str.split(".");
        this.inter = strArr[0];
        this.decimal = strArr[1];
    }

    get customStyle(): any {
        return {
            fontSize: `${getRealPx(this.baseSize ?? 24)}px`,
            color: this.color
        };
    }

    get interStyle(): any {
        return {
            fontSize: `${getRealPx(this.interSize ?? 32)}px`
        };
    }

    get lineStyle(): any {
        return {
            fontSize: `${getRealPx(this.lineSIze ?? 20)}px`
        };
    }
}
</script>

<style lang="scss" scoped>
.base-format-money {
    font-weight: 600;
    .line {
        margin-left: 13px;
        font-weight: 400;
        text-decoration: line-through;
        color: #999999;
    }
}
</style>
