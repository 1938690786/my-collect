<template>
    <div class="page-visible"></div>
</template>
<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
@Component({
    name: "BasePageVisible"
})
export default class BasePageVisible extends Vue {
    handleVisible(e: any): void {
        if (e.target.visibilityState === "hidden") {
            // 页面隐藏
            this.$emit("hidden");
        } else if (e.target.visibilityState === "visible") {
            // 页面显示
            this.$emit("visible");
        } else {
            // 无效操作
        }
    }

    mounted(): void {
        // 监听页面隐藏和显示状态
        document.addEventListener("visibilitychange", this.handleVisible);
    }

    beforeDestroy(): void {
        document.removeEventListener("visibilitychange", this.handleVisible);
    }
}
</script>
