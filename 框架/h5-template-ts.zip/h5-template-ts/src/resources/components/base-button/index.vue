<template>
    <van-button :class="['base-button', `base-button_${type}`]" v-bind="$attrs" v-on="$listeners">
        <slot name="default" />
    </van-button>
</template>

<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import { Button } from "vant";

@Component({
    components: {
        [Button.name]: Button
    }
})
export default class BaseButton extends Vue {
    @Prop({
        default: ""
    })
    type?: string;
}
</script>

<style lang="scss" scoped>
@mixin set-background-color($color) {
    background: $color;
}
@mixin set-color($color) {
    color: $color;
}
.base-button {
    height: 74px;
    color: #fff;
    font-size: 26px;
    &_text {
        border: 0 none;
        @include set-color(#3b3b3b);
    }
    &_text-danger {
        border: 0 none;
        @include set-color(#f12f1a);
    }
    &_default {
        @include set-background-color(#fff);
    }
    &_danger {
        @include set-background-color(#f12f1a);
    }
    &_transparent {
        background: initial;
    }
    &_yellow {
        @include set-background-color(#fca522);
    }
    &_pink {
        @include set-background-color(#ffeeee);
    }
    &_gray {
        @include set-background-color(#999);
    }
    &_gray-1 {
        @include set-background-color(#f6f5f5);
    }
}
</style>
