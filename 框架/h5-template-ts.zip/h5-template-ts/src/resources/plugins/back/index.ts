/*
 * @Description:
 * @Autor: hanxinxin
 * @Date: 2021-04-19 15:32:49
 * @LastEditors: hanxinxin
 * @LastEditTime: 2021-04-20 09:29:28
 * @FilePath: \h5-template\src\frame-work\plugins\back\back.ts
 */
import { PluginObject } from "vue";
import router from "@/packages/vue-router/index";
import store from "@/packages/vuex/index";

const Back: PluginObject<never> = {
    install(Vue) {
        Vue.prototype.$back = (): any => {
            router.go(-1);
            store.commit("SET_ISBACK", true);
        };
    }
};

export default Back;
