// eslint-disable-next-line no-unused-vars,@typescript-eslint/no-unused-vars
import Vue from "vue";
declare module "vue/types/vue" {
    interface Vue {
        /**
         * 回退（到底则退出webview）
         */
        $back(): void;
    }
}
