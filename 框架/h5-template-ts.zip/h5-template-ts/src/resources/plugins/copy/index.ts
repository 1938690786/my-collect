/* 全局挂载copy方法
 * @Author: zhoukai
 * @Date: 2022-02-15 10:27:59
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2022-02-15 16:27:23
 */

import Vue from "vue";
import { handlerCopy } from "./core";

Vue.prototype.$copy = handlerCopy;
