/* eslint-disable no-unused-vars,@typescript-eslint/no-unused-vars*/
import Vue from "vue";

declare module "vue/types/vue" {
    interface Vue {
        /**
         * Promise的自动重试，需要传入一个Promise方法
         * @param req 构造Promise
         * @param limit 重试次数，默认3
         * @param delay 重试延迟，默认50毫秒
         */
        $retry(
            req: {
                fn: (params?: any) => Promise<any>;
                params?: any;
            },
            limit?: number,
            delay?: number
        ): Promise<any>;
    }
}
