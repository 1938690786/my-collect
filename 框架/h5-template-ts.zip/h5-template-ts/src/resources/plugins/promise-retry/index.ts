/* Promise的自动重试，需要传入一个Promise方法
 * @Author: hanxinxin
 * @Date: 2021-05-06 09:37:55
 * @Last Modified by: hanxinxin
 * @Last Modified time: 2021-12-23 09:47:43
 */
import { PluginObject } from "vue";

const Retry: PluginObject<never> = {
    install(Vue) {
        Vue.prototype.$retry = (
            req: {
                // eslint-disable-next-line no-unused-vars
                fn: (params?: any) => Promise<any>;
                params?: any;
            },
            limit = 3,
            delay = 50
        ): Promise<any> => {
            return new Promise((resolve, reject) => {
                const attempt = async (): Promise<any> => {
                    try {
                        const res = await req.fn(req.params);
                        resolve(res);
                    } catch (e) {
                        limit--;
                        if (!limit) {
                            reject(e);
                        } else {
                            setTimeout(() => {
                                attempt();
                            }, delay);
                        }
                    }
                };
                attempt();
            });
        };
    }
};

export default Retry;
