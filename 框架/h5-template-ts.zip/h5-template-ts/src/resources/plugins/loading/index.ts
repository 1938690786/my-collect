import { PluginObject } from "vue";
import { globalMountVueComponent } from "@/utils/dev/index";
import MyLoading from "./index.vue";

const Loading: PluginObject<{ noAdditional: boolean }> = {
    install(Vue, options) {
        const noAdditional = options && options.noAdditional;

        const myTpl = globalMountVueComponent(MyLoading, noAdditional);
        document.body.appendChild(myTpl.$el);

        Vue.prototype.$loading = (text: string): any => {
            return myTpl.active(text);
        };
        Vue.prototype.$loading.clear = (): void => {
            (myTpl as any).disband();
        };
    }
};
export default Loading;
