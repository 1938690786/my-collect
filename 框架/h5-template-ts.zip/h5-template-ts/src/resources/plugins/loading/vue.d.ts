// eslint-disable-next-line no-unused-vars,@typescript-eslint/no-unused-vars
import Vue from "vue";
declare module "vue/types/vue" {
    interface Vue {
        $loading: {
            (): void;
            clear: () => void;
        };
    }
}
