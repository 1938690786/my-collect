<template>
    <transition name="fade">
        <div v-if="isActive" class="loading-dialog">
            <div class="bg"></div>
            <div class="loading-wrapper">
                <div class="loading-content">
                    <div class="icon"></div>
                </div>
                <div v-if="text" class="text-content">
                    {{ text }}
                </div>
            </div>
        </div>
    </transition>
</template>
<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
@Component
export default class Loading extends Vue {
    isActive = false;
    text?: string = "";
    active(text: string | number): void {
        this.text = String(text ?? "");
        this.isActive = true;
    }
    disband(): void {
        this.isActive = false;
    }
}
</script>
<style lang="scss" scoped>
@import "@/styles/utils/@theme-color";
$themeColor: #409eff;

.loading-dialog {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 130;

    .bg {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: rgba(225, 225, 225, 0.4);
    }

    .loading-wrapper {
        width: 240px;
        height: 230px;
        padding: 20px 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        .loading-content {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 64px;
            height: 64px;
            .icon {
                width: 46px;
                height: 46px;
                margin: 1px;
                border-radius: 50%;
                border: 5px solid transparent;
                border-color: $themeColor transparent;
                animation: spin 1.2s linear infinite;
            }
        }
        .text-content {
            flex-shrink: 0;
            font-size: 26px;
            line-height: 70px;
            color: #ffffff;
            text-align: center;
            padding: 0 18px;
        }
    }
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}
</style>
