/* 提供插件
 * @Author: hanxinxin
 * @Date: 2021-04-21 09:50:25
 * @Last Modified by: hanxinxin
 * @Last Modified time: 2021-09-23 13:37:48
 */
import Vue from "vue";
import VConsole from "vconsole";
// import * as Sentry from "@sentry/browser";
// import * as Integrations from "@sentry/integrations";

// /** 生产环境，提供sentry能力 */
// if (process.env.VUE_APP_MODE === "production") {
//     Sentry.init({
//         dsn: process.env.VUE_APP_SENTRY,
//         integrations: [new Integrations.Vue({ Vue, attachProps: true })]
//     });
// }

/** 非生产环境，提供vconsole能力 */
if (process.env.VUE_APP_MODE !== "production") {
    Vue.prototype.$vConsole = new VConsole();
}

/** 提供log挂载,用于模板对象调试 */
Vue.prototype.$log = console.log;
