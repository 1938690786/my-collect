/* 导出核心方法
 * @Author: hanxinxin
 * @Date: 2021-04-21 09:36:56
 * @Last Modified by: hanxinxin
 * @Last Modified time: 2021-12-28 14:14:20
 */
import Vue from "vue";

import "./lib";
import "./copy";
import { Toast, Dialog, Lazyload, Sticky, Image as VanImage, Notify } from "vant";
import Loading from "./loading/index";
import Back from "./back/index";
import Retry from "./promise-retry/index";

Vue.use(Toast);
Vue.use(Notify);
Vue.use(Dialog);
Vue.use(Lazyload);
Vue.use(Sticky);
Vue.use(Loading);
Vue.use(Back);
Vue.use(Retry);
Vue.use(VanImage);
