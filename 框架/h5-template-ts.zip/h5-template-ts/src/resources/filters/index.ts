import Vue from "vue";
import { formatMoney } from "./format-money/index";
import { formatDate } from "./format-date/index";

Vue.filter("formatMoney", formatMoney);
Vue.filter("formatDate", formatDate);
