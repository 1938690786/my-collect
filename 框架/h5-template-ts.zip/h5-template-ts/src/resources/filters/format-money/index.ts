export function formatMoney(num: string | number | undefined): string {
    if (num === undefined) {
        return "NaN";
    }
    return num.toLocaleString();
}
