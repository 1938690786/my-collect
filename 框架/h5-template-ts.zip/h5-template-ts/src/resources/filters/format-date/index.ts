import dateHelper from "@/utils/helper/date";

export function formatDate(timestamp: number): string {
    return dateHelper.formatDateTimeStamp(timestamp, "YYYY-MM-DD");
}
