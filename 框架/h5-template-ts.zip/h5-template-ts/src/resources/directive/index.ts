import Vue, { PluginObject } from "vue";
import CopyHookFunction from "./copy/index";
const Directives: PluginObject<never> = {
    install(Vue) {
        Vue.directive("copy", CopyHookFunction);
    }
};
Vue.use(Directives);
