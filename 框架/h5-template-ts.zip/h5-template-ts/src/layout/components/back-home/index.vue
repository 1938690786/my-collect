<template>
    <div
        v-if="showBack"
        id="back-content"
        class="back-content"
        @touchstart="dvStart"
        @touchmove="dvMove"
        @touchend="dvEnd"
        @touchcancel="dvEnd"
    ></div>
</template>

<script lang="ts">
import getRealPx from "@/utils/tools/get-realpx";
import throttle from "@/utils/tools/throttle";
import { Vue, Component } from "vue-property-decorator";

@Component({
    name: "BackHome",
    components: {}
})
export default class BackHome extends Vue {
    /** 触摸开始 */
    touchStartTime = 0;

    /** 触摸实体 */
    toucheEvent: TouchEvent | null = null;

    /** 是否显示返回按钮 */
    get showBack(): boolean {
        return this.$store.state.showBack;
    }

    /** div触发 */
    dvStart(e: TouchEvent): void {
        e.preventDefault();
        this.touchStartTime = new Date().getTime();
    }
    /** div移动 */
    dvMove(e: TouchEvent): void {
        this.toucheEvent = e;
        this.throttleMove();
    }
    /** 节流 */
    // eslint-disable-next-line no-unused-vars
    throttleMove = throttle(function (this: BackHome) {
        if (this.toucheEvent) {
            this.doMove(this.toucheEvent);
        }
    }, 10);

    //TODO:应该使用translate3D来实现移动效果，减少重排操作
    /** 执行移动 */
    doMove(e: TouchEvent): void {
        // debugger;
        const screenHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
        const screenWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        const dv = document.getElementById("back-content");
        if (!dv) {
            return;
        }
        /** 判断Y轴边界 */
        if (e.touches[0].pageY < getRealPx(96) / 2 || e.touches[0].pageY > screenHeight - getRealPx(96) / 2) {
            return;
        }
        /** 判断X轴边界 */
        if (e.touches[0].pageX < getRealPx(96) / 2 || e.touches[0].pageX > screenWidth - getRealPx(96) / 2) {
            return;
        }
        dv.style.bottom = screenHeight - e.touches[0].pageY - getRealPx(96) / 2 + "px";
        dv.style.right = screenWidth - e.touches[0].pageX - getRealPx(96) / 2 + "px";
    }
    // div结束移动
    dvEnd(): void {
        /** 通过结束移动的时间，判断是否是点击事件 */
        console.log("触摸时间：", new Date().getTime() - this.touchStartTime);
        if (new Date().getTime() - this.touchStartTime < 200) {
            this.$router.replace({
                path: "/"
            });
        }
    }
}
</script>

<style lang="scss" scoped>
.back-content {
    @include flex-center;
    position: absolute;
    bottom: 180px;
    right: 25px;
    width: 144px;
    height: 144px;
    background: #000000;
    // opacity: 0.6;
    border-radius: 50%;
    z-index: 10;
    background: url("~@/assets/images/home-icon@2x.png") no-repeat;
    background-size: 100% 100%;
    img {
        width: 44px;
        height: 39px;
    }
}
</style>
