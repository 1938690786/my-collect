<template>
    <van-tabbar :fixed="false" route active-color="#F12F1A" inactive-color="#000" :safe-area-inset-bottom="true">
        <template v-for="(item, index) in tabs">
            <van-tabbar-item :key="index" replace :to="item.router" :badge="item.badge">
                <span>{{ item.title }}</span
                ><template #icon="props"><img :src="props.active ? item.active : item.inactive" /></template
            ></van-tabbar-item>
        </template>
    </van-tabbar>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
import { Tabbar, TabbarItem } from "vant";
import tabbar from "@/config/tabbar";
@Component({
    name: "LayoutTabbar",
    components: {
        [Tabbar.name]: Tabbar,
        [TabbarItem.name]: TabbarItem
    }
})
export default class LayoutTabbar extends Vue {
    get tabs(): any {
        return tabbar;
    }
}
</script>

<style lang="scss" scoped>
::v-deep .van-info {
    background-color: #fb2010;
}
::v-deep.van-hairline--top-bottom::after,
.van-hairline-unset--top-bottom::after {
    border-bottom-width: 0;
}
</style>
