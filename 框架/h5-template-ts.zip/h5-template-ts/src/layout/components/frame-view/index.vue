<template>
    <div
        class="frame-view top-safe-area"
        :class="[showTabbar ? '' : 'bottom-safe-area']"
        :style="{ backgroundColor: backgroundColor }"
    >
        <!-- 兼容安卓头部用的空标签  -->
        <div :style="{ height: `${getSafeAreaTop}px`, width: '100vw' }"></div>
        <!-- 头部导航  -->
        <div v-if="showNavbar" class="frame-view-header">
            <div class="frame-view-header__left"><slot name="nav-left"></slot></div>
            <div class="frame-view-header__title">{{ title }}</div>
            <div class="frame-view-header__left"><slot name="nav-right"></slot></div>
        </div>
        <!-- 内容区域 -->
        <div class="frame-view-content">
            <template v-if="!error">
                <base-loading :loading="loading" class="frame-view-loading">
                    <slot></slot>
                </base-loading>
                <!-- 底部插槽   :class="[footerBottom ? 'base-footer-bottom' : '']" -->
                <div v-if="$slots.footer" class="base-footer" :style="bottomstyle">
                    <slot name="footer"></slot>
                </div>
            </template>
            <!-- 错误状态 -->
            <template v-else>
                <base-empty :image="image" :type="type" :desc="desc"></base-empty>
            </template>
        </div>
        <!-- 底部tabbar -->
        <layout-tabbar v-if="showTabbar" class="frame-view-tabbar"></layout-tabbar>
        <!-- 返回首页按钮 -->
        <template v-if="isBackHome">
            <back-home></back-home>
        </template>
    </div>
</template>
<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import BaseFooter from "@/resources/components/base-footer/index.vue";
import BaseLoading from "@/resources/components/base-loading/index.vue";
import BaseEmpty from "@/resources/components/base-empty/index.vue";
import LayoutTabbar from "../layout-tabbar/index.vue";
import uaHelper from "@/utils/helper/ua";
import getUrlkey from "@/utils/tools/get-urlkey";
import BackHome from "../back-home/index.vue";
import getRealPx from "@/utils/tools/get-realpx";

@Component({
    components: {
        BaseFooter,
        BaseLoading,
        BaseEmpty,
        LayoutTabbar,
        BackHome
    }
})
export default class FrameView extends Vue {
    isBackHome = false;
    getSafeAreaTop = 0;
    /** 加载状态 */
    @Prop({
        default: false
    })
    loading?: boolean;

    /** 错误状态*/
    @Prop({
        default: false
    })
    error?: boolean;

    /** 空状态预定义类型 【注：仅当 error 设置为 true 的时候有效】*/
    @Prop({
        default: "result"
    })
    type?: string;

    /** 空状态自定义图片，同vant-empty接收的image */
    @Prop()
    image?: string;

    /** 空状态自定义描述  【注：仅当 error 设置为 true 的时候有效】 */
    @Prop({
        default: false
    })
    desc?: string;

    /** 是否显示tabbar */
    @Prop()
    tabbar?: boolean;

    @Prop()
    footerBottom?: number;

    /** 头部title */
    @Prop()
    title?: string;

    /** 自定义背景色 */
    @Prop({
        default: "#f4f5f6"
    })
    backgroundColor?: string;

    get bottomstyle(): any {
        return {
            bottom: getRealPx(this.footerBottom || 0) + "px"
        };
    }

    /** 是否显示头部导航 */
    get showNavbar(): boolean {
        return uaHelper.inApp;
    }

    /**是否tabbar页*/
    get showTabbar(): boolean {
        /** 适配APP */
        if (uaHelper.inApp) {
            return false;
        }
        return (this.$route.meta?.isTabbar === true && this.tabbar !== false) || this.tabbar === true;
    }

    //获取安卓app那边返回的手机顶部高度 做兼容性处理
    getTopbarHeight(): void {
        try {
            this.$nativeApp.handleMethods("getSafeAreaTop", (back: string) => {
                console.log("接收到getSafeAreaTop：", back);
                if (Number(back) > 0) {
                    this.getSafeAreaTop = Number(back) / 3;
                } else {
                    this.getSafeAreaTop = Number(back);
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    mounted(): void {
        if (getUrlkey("isBack")) {
            this.isBackHome = true;
        } else {
            this.isBackHome = false;
        }
        if (uaHelper.isAndroidApp) {
            this.getTopbarHeight();
        }
    }
}
</script>
<style lang="scss" scoped>
.frame-view {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    position: relative;
    width: 100%;
    height: 100%;
    .frame-view-header {
        user-select: none;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 80px;
        width: 100%;
        font-weight: 700;
        z-index: 48;
        font-size: 30px;
    }
    .frame-view-content {
        width: 100%;
        // -webkit-overflow-scrolling: touch;
        height: 100%;
        overflow-y: scroll;
        ::-webkit-scrollbar {
            display: none;
        }
        .frame-view-loading {
            height: 100%;
        }
    }
    .frame-view-tabbar.van-tabbar {
        min-height: 100px;
    }
    .base-footer {
        box-sizing: content-box;
        position: fixed;
        bottom: 0;
        left: 0;
        background-color: #fff;
        width: 100vw;
        height: 100px;
        font-size: 26px;
        padding-bottom: constant(safe-area-inset-bottom);
        padding-bottom: env(safe-area-inset-bottom);
    }
    .base-footer-bottom {
        position: fixed;
        bottom: 100px;
        left: 0;
    }
}
.top-safe-area {
    padding-top: constant(safe-area-inset-top);
    padding-top: env(safe-area-inset-top);
}
.bottom-safe-area {
    padding-bottom: constant(safe-area-inset-bottom);
    padding-bottom: env(safe-area-inset-bottom);
}
</style>
