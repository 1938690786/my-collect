/* 导出核心组件
 * @Author: hanxinxin
 * @Date: 2021-04-20 15:10:46
 * @Last Modified by: hanxinxin
 * @Last Modified time: 2021-11-10 17:04:38
 */

import Vue, { PluginObject } from "vue";
import FrameView from "./components/frame-view/index.vue";

const Components: PluginObject<never> = {
    install(Vue) {
        Vue.component("FrameView", FrameView);
    }
};

Vue.use(Components);
