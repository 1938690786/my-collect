import Vue from "vue";
import App from "./app.vue";
import router from "@/packages/vue-router/index";
import store from "@/packages/vuex";

/***************** 样式相关 ***************/
import "@/styles/index.scss";
/***************** 公共 components plugins ***************/
//导入布局
import "@/layout/index";
//导入插件
import "@/resources/plugins/index";
//注册全局自定义指令
import "@/resources/directive/index";
//注册筛选函数
import "@/resources/filters/index";
//native-bridge
import "@/utils/tools/native-bridge";
//微信相关
import "@/utils/tools/wx/index";
//svg图片处理
import "@/assets/svg/index";

Vue.config.productionTip = false;

// 配置vue忽略标签名
Vue.config.ignoredElements = ["wx-open-launch-weapp", "wx-open-launch-app", "wx-open-subscribe", "wx-open-audio"];

new Vue({
    router,
    store,
    render: (h): any => h(App)
}).$mount("#app");
