import request from "@/packages/request/index";

export function list(params?: any, data?: any): any {
    return request({
        url: "/baseapi/app/investmentNoAuth/getList",
        params,
        data
    });
}

export function listlevel(params?: any, data?: any): any {
    return request({
        url: "http://yapi.syy.dongchali.cn/mock/338/app/goods/goods/%7Bid%7D",
        params,
        data,
        headers: {
            "access-token": "549-gR5x6Ti2ApLwRN9nNfq3oERdGvBpV9rC"
        }
    });
}

export function test(): any {
    return request({
        url: "https://api.telegram.org/bot606248605:AAGv_TOJdNNMc_v3toHK_X6M-dev_1tG-JA/getUpdates",
        method: "GET",
        retry: true,
        retryCount: 2,
        retryDelay: 1000,
        loading: true
    });
}
