import request from "@/packages/request/index";
import {
    AddressListInfo,
    AddAddressParams,
    EditAddressParams,
    DeleteAddressData,
    AccountList,
    GetPersonalData,
    GetSupData
} from "/#/user";

type loginRes = {
    token: string;
    /** token有效期，单位秒 */
    expires_in: number;
    /** 是否注册，true：需要注册，false：已注册 */
    register: boolean;
    /** 手机号 */
    tel: string;
    /** 用户ID */
    id: number;
    /** 品牌ID */
    brand_id: string;
    /** 0 未注册 1已注册未申请代理 2前往审核页 3登录成功 */
    status: number;
    /** 微信信息 */
    open_id: string;
    union_id: string;
    image: string;
    username: string;
    sex: string;
};
/**
 * 自动登录
 * http://yapi.syy.dongchali.cn/project/338/interface/api/22905
 * @param code 微信授权code
 * @param invite_code 邀请码
 * @param brand_id 品牌ID
 * @returns
 */
export function autoLogin(data: { code: string; invite_code?: string; brand_id?: string }): Promise<loginRes> {
    return request({
        url: "/agent_factor/auth/login",
        method: "POST",
        enableCancel: false,
        data
    });
}

/**
 * 验证码登录
 * http://yapi.syy.dongchali.cn/project/338/interface/api/21870
 * @param tel 手机号
 * @param verification_code 验证码
 * @returns
 */
export function verLogin(tel: string, verification_code: number): Promise<{ brand_id: string; token: string }> {
    return request({
        method: "POST",
        url: "/agent_factor/auth/checkLogin",
        throttle: true,
        data: {
            tel,
            verification_code
        }
    });
}

type regForm = {
    /** 微信信息 */
    union_id: string;
    open_id: string;
    username: string;
    image: string;
    sex: string;
    /** 手机号 */
    tel: string;
    /** 验证码 */
    verification_code: string;
    /** 邀请码 */
    invite_code: string;
};
type regRes = {
    token: string;
    expires_in: number;
    /** false 已注册 true需要注册 */
    register: boolean;
    /** 0 未注册 1已注册未申请代理 2未审核 3登录成功 */
    status: number;
    /** 品牌id */
    brand_id: string;
};
/**
 * 手机号+验证码注册
 * http://yapi.syy.dongchali.cn/project/338/interface/api/23793
 * @param data
 * @returns
 */
export function register(data: regForm): Promise<regRes> {
    return request({
        method: "POST",
        url: "/agent_factor/auth/register",
        data
    });
}

/**
 * 个人中心-基础资料
 * @param personalData
 * @returns
 */
interface personalData {
    agent_name?: string;
    agent_wx?: string;
    agent_sex?: string;
    agent_birthday?: string;
    tel?: string;
    city?: string;
    province?: string;
    country?: string;
    agent_official?: string;
    id_card_no?: string;
    image?: string;
    id_card_pic_a?: string;
    id_card_pic_b?: string;
}

export function editPersonalData(data: personalData): Promise<personalData> {
    return request({
        url: "/app/agent/agentEdit",
        method: "get",
        data
    });
}

/**
 * 查看代理商信息
 * http://yapi.syy.dongchali.cn/project/338/interface/api/22140
 */
export interface PersonalDataReturnParam {
    image?: string; //头像
    agent_name?: string; //代理商名称
    agent_sex?: number; //代理商性别 0 未知  1男，2女
    tel?: string; //手机
    province?: number; //省id
    city?: number; //市id
    country?: number; //区id
    address?: string; //地址
    agent_wx?: string; //微信号
    agent_wx_pic?: string; //微信二维码
    level?: number; //等级
    level_name?: string; //等级名称
    area?: string; //区域
    is_config_address?: number; //是否配置账户 0 1
    is_config_account?: number; //是否配置地址 0  1
}
export function getPersonalData(): Promise<PersonalDataReturnParam> {
    return request({
        url: "/agent_factor/agent",
        method: "get"
    });
}

/**
 * 个人中心-收货地址列表
 * http://yapi.syy.dongchali.cn/project/338/interface/api/24058
 * @param address_type: 1 为收货地址 2 店铺地址
 * @returns AddressListInfo
 */
export function addressList(params: any): Promise<AddressListInfo> {
    return request({
        url: "/agent_factor/address",
        method: "get",
        params
    });
}

/**
 * 个人中心-地址列表-新增地址
 * @param
 * http://yapi.syy.dongchali.cn/project/338/interface/api/22460
 * @returns
 */
export function addAddress(data: AddAddressParams): Promise<any> {
    return request({
        url: "/agent_factor/address",
        method: "POST",
        data
    });
}

/**
 * 个人中心-地址列表-修改地址
 * @param
 * http://yapi.syy.dongchali.cn/project/338/interface/api/22496
 * @returns
 */
export function editAddress(params: EditAddressParams, data: AddAddressParams): Promise<any> {
    return request({
        url: `/agent_factor/address/${params.address_id}/edit`,
        method: "PUT",
        data
    });
}

/**
 * 个人中心-地址列表-删除地址
 * @param
 * http://yapi.syy.dongchali.cn/project/81/interface/api/11291
 * @returns
 */
export function deleteAddress(data: DeleteAddressData): Promise<any> {
    return request({
        url: `/agent_factor/address/${data.id}`,
        method: "DELETE",
        data
    });
}

/**
 * 个人中心-收款账户
 * @param
 * http://yapi.syy.dongchali.cn/project/338/interface/api/24078
 * @returns
 */
export function accountList(): Promise<AccountList> {
    return request({
        url: `/agent_factor/account/`,
        method: "GET"
    });
}

/**
 * 个人中心-代理商信息和角标
 * @param
 * http://yapi.syy.dongchali.cn/project/338/interface/api/24108
 * @returns
 */
export function getPersonal(): Promise<GetPersonalData> {
    return request({
        url: `/agent_factor/getPersonal`,
        method: "GET"
    });
}

/**
 * 个人中心-联系上级
 * @param
 * http://yapi.syy.dongchali.cn/project/338/interface/api/24110
 * @returns
 */
export function getSup(): Promise<GetSupData> {
    return request({
        url: `/agent_factor/agent/getSup`,
        method: "GET"
    });
}

/**
 * 绑定手机号
 * @param
 * http://yapi.syy.dongchali.cn/project/338/interface/api/22257
 * @returns
 */
export function editTel(agent_id: string, params: { tel: string; code: string }): Promise<{ data: boolean }> {
    return request({
        url: `/agent_factor/agent/${agent_id}/editTel`,
        method: "PUT",
        params
    });
}
