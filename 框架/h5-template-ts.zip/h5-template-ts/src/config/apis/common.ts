import request from "@/packages/request/index";

/**
 * 上传图片
 * @param file
 * @returns
 */
export function uploadImage(file: HTMLFormElement): Promise<{
    url: string;
}> {
    const data = new FormData();
    data.append("file", file.file);
    data.append("type", "folder");
    return request({
        url: "/agent/common/images",
        method: "POST",
        headers: { "Content-Type": "multipart/form-data" },
        enableCancel: false,
        data
    });
}

/**
 * 获取验证码
 * @param mobile 手机号
 * @returns
 */
export function getVerify(mobile: string): Promise<string> {
    return request({
        url: "/api/verify/mobile",
        loading: true,
        params: {
            mobile: mobile
        }
    });
}
