import request from "@/packages/request/index";

interface configInterface {
    url: string;
    jsApilist?: string[];
}

/**获取微信配置*/
export function getWxConfig(data: configInterface): Promise<{
    appId: string;
    nonceStr: string;
    timestamp: number;
    /**当前前端请求url地址*/
    url: string;
    signature: string;
}> {
    const url = "/baseapi/app/auth/getJssdkConfig";
    return request({
        url,
        method: "POST",
        data: data,
        retry: false,
        loading: true
    });
}
