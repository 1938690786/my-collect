import request from "@/packages/request/index";
export interface _AgentDataField {
    agent_name: number;
    agent_wx: number;
    agent_no: number;
    area: number;
    address: number;
    agent_sex: number;
    agent_birthday: number;
    agent_official: number;
}

export interface _RegisterForm {
    /**邀请信息code*/
    brand_code: string;
    /**代理商名称*/
    agent_name?: string;
    /**代理商微信*/
    agent_wx?: string;
    /**代理商身份证号*/
    agent_no?: string;
    /**省市区id*/
    area?: string;
    /**详细地址*/
    address?: string;
    /**代理商性别*/
    agent_sex?: number;
    /**代理生日*/
    agent_birthday?: string;
    /**代理学历*/
    agent_official?: number;
    /**身份证正面*/
    id_card_pic_a?: string;
    /**身份证反面*/
    id_card_pic_b?: string;
}

export interface _RegArea {
    area_id: number;
    value: number;
    label: string;
    children: _RegArea;
}

/**
 * 获取代理商资料填写字段
 * http://yapi.syy.dongchali.cn/project/81/interface/api/11777
 * @returns
 */
export function getAgentDataField(brandId: string): Promise<_AgentDataField> {
    return request({
        url: `/agent_factor/invite/${brandId}/getFormConfig`
    });
}

/**
 * 代理商资料填写
 * http://yapi.syy.dongchali.cn/project/81/interface/api/11795
 * @param data
 * @returns
 */
export function agentRegister(data: _RegisterForm): Promise<boolean> {
    return request({
        url: "/app/agent/agentRegister",
        method: "POST",
        data
    });
}

/**
 * 获取省市区地址
 * http://yapi.syy.dongchali.cn/project/338/interface/api/24044
 * @returns
 */
export function getArea(): Promise<_RegArea[]> {
    return request({
        url: "/config/areaData",
        method: "GET",
        enableCancel: false
    });
}
