/* eslint-disable no-unused-vars */
/** 订单类型 */
export enum EnumOrderType {
    采购订单 = 1,
    提货定单 = 2,
    换货订单 = 3,
    招商订单 = 4
}

/** 取货类型 */
export enum EnumTakeType {
    物流 = 0,
    自提 = 1,
    云库存 = 2
}
