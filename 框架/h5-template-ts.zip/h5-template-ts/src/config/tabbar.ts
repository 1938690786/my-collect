const tabbar = [
    {
        router: "/index",
        title: "首页",
        inactive: require("@/assets/images/base/index@2x.png"),
        active: require("@/assets/images/base/index-active@2x.png")
    },
    {
        router: "/category",
        title: "分类",
        inactive: require("@/assets/images/base/deliver@2x.png"),
        active: require("@/assets/images/base/deliver-active@2x.png")
    },
    {
        router: "/business/index",
        title: "会员",
        inactive: require("@/assets/images/base/recruit@2x.png"),
        active: require("@/assets/images/base/recruit-active@2x.png")
    },
    {
        router: "/card",
        title: "购物车",
        inactive: require("@/assets/images/base/stimulate@2x.png"),
        active: require("@/assets/images/base/stimulate-active@2x.png")
    },
    {
        router: "/user",
        title: "我的",
        inactive: require("@/assets/images/base/user@2x.png"),
        active: require("@/assets/images/base/user-active@2x.png")
    }
];
export default tabbar;
