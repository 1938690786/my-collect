/* mock数据
 * @Author: hanxinxin
 * @Date: 2021-04-20 15:09:54
 * @Last Modified by: zhangkejia
 * @Last Modified time: 2021-09-03 09:43:47
 */

type mock = { api: string; method: "GET" | "POST" | "DELETE" | "PUT" };

const MOCK_STATUS = true;

const MOCK_SERVER = "http://yapi.syy.dongchali.cn/mock/338";

const MOCK_LIST: mock[] = [
    {
        api: "/app/goods/goods",
        method: "GET"
    }
];

export { MOCK_SERVER, MOCK_LIST, MOCK_STATUS };
