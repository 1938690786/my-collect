import { RouteConfig } from "vue-router";

let routers: RouteConfig[] = [];

if (process.env.VUE_APP_MODE === "development") {
    routers = [
        {
            path: "/dev",
            name: "dev",
            meta: {
                title: "开发者工具"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/index.vue")
        },
        {
            path: "/dev/visible",
            name: "dev-visible",
            meta: {
                title: "页面显示监听"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/visible/index.vue")
        },
        {
            path: "/dev/list",
            name: "dev-list",
            meta: {
                title: "数据流式加载"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/list/index.vue")
        },
        {
            path: "/dev/float",
            name: "dev-float",
            meta: {
                title: "浮点运算"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/float/index.vue")
        },
        {
            path: "/dev/loading",
            name: "dev-loading",
            meta: {
                title: "局部加载动画"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/loading/index.vue")
        },
        {
            path: "/dev/progress",
            name: "dev-progress",
            meta: {
                title: "进度条"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/progress/index.vue")
        },
        {
            path: "/dev/table",
            name: "dev-table",
            meta: {
                title: "表格"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/table/index.vue")
        },
        {
            path: "/dev/collapse",
            name: "dev-collapse",
            meta: {
                title: "折叠面板"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/collapse/index.vue")
        },
        {
            path: "/dev/cell",
            name: "dev-cell",
            meta: {
                title: "折叠面板"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/cell/index.vue")
        },
        {
            path: "/dev/cell",
            name: "dev-cell",
            meta: {
                title: "基础单元格"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/cell/index.vue")
        },
        {
            path: "/dev/swiper",
            name: "dev-swiper",
            meta: {
                title: "轮播图"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/swiper/index.vue")
        },
        {
            path: "/dev/copy",
            name: "dev-copy",
            meta: {
                title: "全局指令之复制"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/copy/index.vue")
        },
        {
            path: "/dev/form",
            name: "dev-form",
            meta: {
                title: "form表单"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/form/index.vue")
        },
        {
            path: "/dev/svg",
            name: "svg",
            meta: {
                title: "svg"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/svg/index.vue")
        },
        {
            path: "/dev/echarts",
            name: "echarts",
            meta: {
                title: "Echarts图表"
            },
            component: (): any => import(/* webpackChunkName: "modules/dev"*/ "@/views/_dev/echarts/index.vue")
        }
    ];
}

export default routers;
