import { RouteConfig } from "vue-router";

const routers: RouteConfig[] = [
    {
        path: "/",
        redirect: "/index"
    },
    {
        path: "/index",
        name: "index",
        meta: {
            title: "首页"
        },
        component: (): any => import(/* webpackChunkName: "modules/index"*/ "@/views/index/index.vue")
    }
];

export default routers;
