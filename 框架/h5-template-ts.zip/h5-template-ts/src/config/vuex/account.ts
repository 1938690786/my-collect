/* 账户相关
 * @Author: hanxinxin
 * @Date: 2021-05-16 15:19:31
 * @Last Modified by: hanxinxin
 * @Last Modified time: 2021-09-26 18:22:03
 */

import validatorHelper from "@/utils/helper/validator";
import storage from "@/utils/tools/storage";

const defaultState = {
    token: ""
};

const state = {
    ...defaultState,
    initState(): any {
        return defaultState;
    }
};

const getters = {};

const mutations = {
    // 设置token
    SET_TOKEN(state: any, res: string): void {
        if (validatorHelper.isStrExist(res)) {
            state.token = res;
            storage.setToken(res);
        }
    },
    // 清除vuex缓存
    CLEAR_VUEX(state: any): void {
        if (state.initState && typeof state.initState === "function") {
            const initState = state.initState();
            for (const key in initState) {
                if (Object.prototype.hasOwnProperty.call(initState, key)) {
                    state[key] = initState[key];
                }
            }
        }
    }
};

const actions = {};

export default {
    namespaced: true,
    state,
    getters,
    mutations,
    actions
};
