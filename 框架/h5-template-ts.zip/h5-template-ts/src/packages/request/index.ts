import { login } from "@/utils/tools/login/index";
import storage from "@/utils/tools/storage";
import uuid from "@/utils/tools/uuid";
import SyyRequest from "@syyfe/request";

import loading from "./loading";
/**
 *定义需要重新登录的code
 */
const loginCode: number[] = [4001];
const service = new SyyRequest({
    base: {
        timeout: 15 * 1000,
        baseURL: process.env.VUE_APP_MODE === "development" ? process.env.VUE_APP_API_URL : "",
        prefix: ""
    },
    loading,
    interceptors: {
        request: (config): Promise<any> => {
            const token = storage.getToken();
            //TODO:token保护机制，当前请求host和env配置文件中的请求host一致时，才允许携带token
            if (token && config?.headers) {
                config.headers["access-token"] = token;
            }

            if (config.method?.toLocaleUpperCase() === "GET") {
                config.params = {
                    ...config.params,
                    _t: uuid()
                };
            }
            return Promise.resolve(config);
        },
        response: (response): Promise<any> => {
            response.data.message = response.data.msg;
            /** 处理特殊情况 */
            if (loginCode.includes(response.data?.code)) {
                //如果需要重新登录，则直接结束
                login();
                return Promise.reject("请重新登录");
            }
            if (response.data.code !== 200) {
                return Promise.reject(response);
            }
            return Promise.resolve(response);
        },
        responseError: (errorResponse): Promise<any> => {
            errorResponse.data.message = errorResponse.data.msg;
            return Promise.reject(errorResponse);
        }
    }
});

const request = service.request;

export function clearRequest(): void {
    service.clearQueue();
}

export default request;
