/* 组合路由并导出
 * @Author: hanxinxin
 * @Date: 2021-04-21 13:00:54
 * @Last Modified by: hanxinxin
 * @Last Modified time: 2021-12-21 16:53:57
 */
import { RouteConfig } from "vue-router";
import baseRouter from "./base";

const modulesFiles = require.context("@/config/router", true, /\.ts$/);
const modules = modulesFiles.keys().reduce((modules: any, modulePath: any) => {
    const moduleName = modulePath.replace(/^\.\/(.*)\.\w+$/, "$1");
    const value = modulesFiles(modulePath);
    modules[moduleName] = value.default;
    return modules;
}, {});

const routers: RouteConfig[] = [];

for (const key in modules) {
    if (key === "dev" && ["development"].includes(<string>process.env.VUE_APP_MODE)) {
        routers.push(...modules[key]);
    }
    if (key !== "dev") {
        routers.push(...modules[key]);
    }
}
routers.push(baseRouter);

export default routers;
