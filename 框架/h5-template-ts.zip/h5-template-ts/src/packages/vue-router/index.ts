import Vue from "vue";
import VueRouter, { RouterOptions, Route } from "vue-router";
import routes from "./routes";
import store from "../vuex/index";

Vue.use(VueRouter);
const VueRouterPush = VueRouter.prototype.push;
const VueRouterReplace = VueRouter.prototype.replace;
VueRouter.prototype.push = function push(location: string): any {
    return (VueRouterPush.call(this, location) as any).catch((err: any) => err);
};

VueRouter.prototype.replace = function replace(location: any): any {
    return (VueRouterReplace.call(this, location) as any).catch((err: any) => err);
};
const options: RouterOptions = {
    mode: "history",
    base: "h5",
    routes
};

const router = new VueRouter(options);
router.beforeEach(async (to: Route, from: Route, next) => {
    document.title = to.meta?.title || "";
    document.getElementById("index-loading")?.setAttribute("style", "display:auto");
    if (from.meta?.keepAlive) {
        const $content = document.querySelector(".frame-view-content");
        const scrollTop = $content?.scrollTop || 0;
        store.commit("SET_SCROLL", scrollTop);
    }
    next();
});

router.afterEach((to) => {
    document.getElementById("index-loading")?.setAttribute("style", "display:none");
    store.commit("SET_SHOWBACK", to.meta?.isTabbar !== true && to.meta?.showBack !== false);
    if (to.meta?.keepAlive) {
        Vue.nextTick(() => {
            const $content = document.querySelector(".frame-view-content");
            if ($content) {
                $content.scrollTop = store.state.scrollTop;
            }
        });
    }
});

export default router;
