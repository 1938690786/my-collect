/* 基础数据
 * @Author: hanxinxin
 * @Date: 2021-05-16 15:21:00
 * @Last Modified by: hanxinxin
 * @Last Modified time: 2021-09-08 09:40:53
 */

const state = {
    // 路由是否后退
    isBack: null,
    // 微信sdk可用状态
    wxSdkStatus: false,
    // 微信开放标签可用状态
    wxOpenTag: false,
    // 滚动条位置
    scrollTop: 0,
    // 是否隐藏返回按钮
    showBack: false
};

const mutations = {
    SET_WXSDK(state: any, res: any): void {
        state.wxSdkStatus = res;
    },
    SET_WXOPENTAG(state: any, res: any): void {
        state.wxOpenTag = res;
    },
    SET_ISBACK(state: any, res: boolean): void {
        state.isBack = res;
    },
    SET_SCROLL(state: any, res: number): void {
        state.scrollTop = res;
    },
    SET_SHOWBACK(state: any, res: boolean): void {
        state.showBack = res;
    }
};

export default {
    state,
    mutations
};
