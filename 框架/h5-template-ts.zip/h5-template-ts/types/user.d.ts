/* 地址列表数据 */
export interface AddressListInfo {
    /** 总数 */
    total: number;
    /** 数组 */
    rows: RowsInfo[];
}

export interface RowsInfo {
    /** id */
    id: number;
    /** 区域 */
    area: string;
    /** 地址 */
    addr: string;
    /** 是否默认：1是0否 */
    is_default: number;
    /** 状态：0家 1公司 2学校 */
    status: number;
    /** 电话 */
    mobile: string;
    /** 姓名 */
    name: string;
}

/* 添加地址传参 */
export interface AddAddressParams {
    /** 姓名 */
    name: string;
    /** 联系电话 */
    mobile: string;
    /** 省id */
    province_id: number;
    /** 市id */
    city_id: number;
    /** 区id */
    country_id: number;
    /** 详细地址 */
    addr: string;
    /** 标签 */
    label: string;
    /** 是否默认 */
    is_default: string;
    /** 地址类型：1为收货地址 2店铺地址 */
    address_type: string;
}

/* 修改地址 */
export interface EditAddressParams {
    address_id: number | string;
}
export interface DeleteAddressData {
    id: string;
}

export interface AccountList {
    /* 总数 */
    total: number;
    rows: RowsData[];
}

export interface RowsData {
    id: number;
    agent_id: number;
    brand_id: number;
    account_order: number;
    open_account_msg: string;
    account_name: string;
    type: number;
    code_images: string;
    is_default: number;
    create_time: string;
}

/* 个人中心-代理商信息和角标 */
export interface GetPersonalData {
    /* 代理商名称 */
    agent_name: string;
    /* 代理商头像 */
    agent_image: string;
    /* 代理商手机号 */
    tel: string;
    /* 等级名称 */
    level_name: string;
    /* 购物车数量 */
    shopping_cart_nums: number;
    /* 待付款数 */
    ready_pay_nums: number;
    /* 已付款数 */
    already_pay_nums: number;
    /* 待收货数 */
    ready_delivery_nums: number;
    /* 待自提数 */
    ready_take_nums: number;
    /* 换货申请数 */
    exchange_apply_nums: number;
}

/* 联系上级 */
export interface GetSupData {
    /* 头像 */
    image: string;
    /* 名称 */
    agent_name: string;
    /* 等级 */
    level: number;
    /* 等级名称 */
    level_name: string;
    /* 手机 */
    tel: string;
    /* 微信 */
    agent_wx: string;
    /* 微信二维码 */
    agent_wx_pic: string;
}
